import json
import os
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Tuple

import numpy as np
import yaml
from mcp.types import ImageContent, TextContent

from dataclasses import dataclass, fields, replace

@dataclass(kw_only=True, frozen=True)
class ToolResult:
    """Represents the result of a tool execution."""

    output: str | None = None
    error: str | None = None
    base64_image: str | None = None
    system: str | None = None

    def __bool__(self):
        return any(getattr(self, field.name) for field in fields(self))

    def replace(self, **kwargs):
        """Returns a new ToolResult with the given fields replaced."""
        return replace(self, **kwargs)


def detect_task_format(task_dir: Path) -> str | None:
    """Auto-detect task format from directory structure.

    Checks each registered format adapter to see if the directory
    contains a valid task for that format.

    Args:
        task_dir: Path to the task directory

    Returns:
        Format name ("apex", "harbor") or None if no format matches.
    """
    from .task_formats import FormatRegistry

    for fmt in FormatRegistry.list_formats():
        try:
            adapter = FormatRegistry.get_adapter(fmt)
            if adapter.is_valid_task(task_dir):
                return fmt
        except ValueError:
            continue
    return None


def validate_task_folder_structure(task_dir: Path, task_format: str = "apex") -> Tuple[bool, List[str]]:
    """
    Validate that a task folder has the correct structure for the given format.

    For apex format:
        Required files: Dockerfile, grader.py, solution.sh, task.yaml
        Optional files: report.json, .apex_metadata.json, setup.sh
        Optional folders: data/, tests/, __pycache__/

    For harbor format:
        Required files: task.toml, instruction.md
        Required folders: environment/ (with Dockerfile), tests/
        Optional folders: solution/, __pycache__/

    Args:
        task_dir: Path to the task directory
        task_format: Task format ("apex" or "harbor")

    Returns:
        Tuple of (is_valid, list_of_errors)
    """
    errors = []

    if not task_dir.exists():
        errors.append(f"Task directory does not exist: {task_dir}")
        return False, errors

    if not task_dir.is_dir():
        errors.append(f"Task path is not a directory: {task_dir}")
        return False, errors

    if task_format == "harbor":
        return _validate_harbor_structure(task_dir)
    else:
        return _validate_apex_structure(task_dir)


def _validate_apex_structure(task_dir: Path) -> Tuple[bool, List[str]]:
    """Validate Apex format task structure."""
    errors = []

    # Required files
    required_files = [
        "Dockerfile",
        "grader.py",
        "solution.sh",
        "task.yaml"
    ]

    # Optional files
    optional_files = [
        "report.json",
        ".apex_metadata.json",
        "setup.sh"
    ]

    # Optional folders
    optional_folders = ["data", "tests", "__pycache__"]

    # Check required files exist
    for required_file in required_files:
        file_path = task_dir / required_file
        if not file_path.exists():
            errors.append(f"Required file missing: {required_file}")
        elif not file_path.is_file():
            errors.append(f"Required file is not a regular file: {required_file}")

    # Get all items in the task directory
    all_items = list(task_dir.iterdir())

    # Check for unexpected files or folders
    allowed_items = set(required_files + optional_files + optional_folders)

    for item in all_items:
        item_name = item.name
        # Skip hidden files/folders and cache directories
        if item_name.startswith(".") or item_name == "__pycache__":
            continue
        if item_name not in allowed_items:
            if item.is_file():
                errors.append(f"Unexpected file found: {item_name}")
            elif item.is_dir():
                errors.append(f"Unexpected folder found: {item_name}")
            else:
                errors.append(f"Unexpected item found: {item_name}")

    # Additional checks for optional files
    for file_name in optional_files:
        file_path = task_dir / file_name
        if file_path.exists() and not file_path.is_file():
            errors.append(f"Optional file '{file_name}' exists but is not a regular file")

    # Additional checks for optional folders
    for folder_name in optional_folders:
        folder_path = task_dir / folder_name
        if folder_path.exists() and not folder_path.is_dir():
            errors.append(f"Optional folder '{folder_name}' exists but is not a directory")

    is_valid = len(errors) == 0
    return is_valid, errors


def _validate_harbor_structure(task_dir: Path) -> Tuple[bool, List[str]]:
    """Validate Harbor format task structure."""
    errors = []

    # Required files
    required_files = [
        "task.toml",
        "instruction.md"
    ]

    # Required folders
    required_folders = [
        "environment",
        "tests"
    ]

    # Optional folders
    optional_folders = ["solution", "__pycache__", "logs", "jobs"]

    # Check required files exist
    for required_file in required_files:
        file_path = task_dir / required_file
        if not file_path.exists():
            errors.append(f"Required file missing: {required_file}")
        elif not file_path.is_file():
            errors.append(f"Required file is not a regular file: {required_file}")

    # Check required folders exist
    for required_folder in required_folders:
        folder_path = task_dir / required_folder
        if not folder_path.exists():
            errors.append(f"Required folder missing: {required_folder}")
        elif not folder_path.is_dir():
            errors.append(f"Required folder is not a directory: {required_folder}")

    # Check for Dockerfile in environment folder
    env_dockerfile = task_dir / "environment" / "Dockerfile"
    if (task_dir / "environment").exists() and not env_dockerfile.exists():
        errors.append("Required file missing: environment/Dockerfile")

    # Check for test.sh in tests folder
    test_script = task_dir / "tests" / "test.sh"
    if (task_dir / "tests").exists() and not test_script.exists():
        errors.append("Required file missing: tests/test.sh")

    # Get all items in the task directory
    all_items = list(task_dir.iterdir())

    # Check for unexpected files or folders
    allowed_items = set(required_files + required_folders + optional_folders)

    for item in all_items:
        item_name = item.name
        # Skip hidden files/folders and cache directories
        if item_name.startswith(".") or item_name == "__pycache__":
            continue
        if item_name not in allowed_items:
            if item.is_file():
                errors.append(f"Unexpected file found: {item_name}")
            elif item.is_dir():
                errors.append(f"Unexpected folder found: {item_name}")
            else:
                errors.append(f"Unexpected item found: {item_name}")

    is_valid = len(errors) == 0
    return is_valid, errors


def read_task_yaml(task_path: str) -> Dict[str, Any]:
    task_yaml_path = os.path.join(task_path, "task.yaml")
    with open(task_yaml_path, "r") as f:
        return yaml.safe_load(f)


def create_problem(
    problem_id: str,
    image: str,
    startup_command: str,
    required_tools: List[str],
    description: str,
    difficulty: str = "easy",
    task_type: str = "computation",
    metadata: Dict[str, Any] = None,
) -> Dict[str, Any]:
    problem = {
        "image": image,
        "startup_command": startup_command,
        "id": problem_id,
        "required_tools": required_tools,
        "scratchpad": "allowed",
        "metadata": {
            "difficulty": difficulty,
            "task_type": task_type,
            "description": description,
        },
    }

    if metadata:
        problem["metadata"].update(metadata)

    return problem


def create_problem_set(
    owner: str,
    name: str,
    description: str,
    category: str,
    language: str,
    problems: List[Dict[str, Any]],
) -> Dict[str, Any]:
    return {
        "problem_set": {
            "owner": owner,
            "name": name,
            "description": description,
            "version": "1.0.0",
            "created_at": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
            "metadata": {
                "category": category,
                "language": language,
                "difficulty": "hard",
            },
            "problems": problems,
        }
    }


def generate_problems_json(output_file: str = "problems.json"):
    tasks_dir = "tasks"
    problems = []

    default_startup_command = "python3 /mcp_server/apex_arena/server.py"

    for task_name in os.listdir(tasks_dir):
        task_path = os.path.join(tasks_dir, task_name)
        if os.path.isdir(task_path):
            try:
                task_data = read_task_yaml(task_path)

                # Create specimen-specific Docker image
                specimen_image = os.getenv("DOCKER_REGISTRY_URL", None)
                assert specimen_image is not None, "DOCKER_REGISTRY_URL is not set"
                specimen_image = specimen_image + task_name + ":latest"

                problem = create_problem(
                    problem_id=task_name,  # Use task name as ID
                    image=specimen_image,
                    startup_command=default_startup_command,
                    required_tools=task_data.get("metadata", {}).get(
                        "required_tools", ["bash", "str_replace_editor"]
                    ),
                    description=task_data.get("prompt", "")[:100] + "...",
                    difficulty=task_data.get("metadata", {}).get(
                        "difficulty", "medium"
                    ),
                    task_type=task_data.get("metadata", {}).get("task_type", "coding"),
                    metadata=task_data.get("metadata", {}),
                )
                problems.append(problem)
            except Exception as e:
                print(f"Error processing {task_name}: {str(e)}")

    problem_set = create_problem_set(
        owner="bespokelabs",
        name="apex-arena",
        description="A collection of programming challenges from various domains",
        category="programming",
        language="python",
        problems=problems,
    )

    with open(output_file, "w") as f:
        json.dump(problem_set, f, indent=2)


def mcp_content_block_to_messages_format(content: TextContent | ImageContent):
    if isinstance(content, TextContent):
        return {"type": "text", "text": content.text}
    elif isinstance(content, ImageContent):
        return {
            "type": "image",
            "source": {
                "data": content.data,
                "media_type": content.mimeType,
                "type": "base64",
            },
        }
    else:
        raise ValueError(f"Invalid content type: {type(content)}")


def messages_to_raw_prompt(system: str | None, messages: list) -> str:
    if not messages:
        raise ValueError("at least one message is required")

    if messages[0]["role"] != "user":
        raise ValueError('first message must use the "user" role')

    # Ensure alternating roles
    prev_role = None
    for msg in messages:
        if msg["role"] == prev_role:
            raise ValueError('roles must alternate between "user" and "assistant"')
        prev_role = msg["role"]

    result = []

    # Add system prompt
    if system and system.strip():
        result.append(system.strip())

    # Add messages
    for msg in messages:
        if msg["role"] == "user":
            result.append("\n\nHuman:")
        else:
            result.append("\n\nAssistant:")

        content = msg["content"]
        if isinstance(content, str):
            if not content.strip():
                raise ValueError("messages must have non-empty content")
            result.append(content)
        else:
            # Handle content blocks
            for block in content:
                if block["type"] == "text":
                    if not block["text"].strip():
                        raise ValueError("text content blocks must be non-empty")
                    result.append(block["text"])
                elif block["type"] == "image":
                    result.append(
                        f'<img src="data:{block["source"]["media_type"]};base64,{block["source"]["data"]}"/>'
                    )
                elif block["type"] == "tool_call":
                    result.append(f'<tool_call>{str(block["parameters"])}"/>')
                elif block["type"] == "tool_result":
                    for tool_result_block in msg["content"]:
                        result.append(
                            f"<tool_result>{str(tool_result_block)}</tool_result>"
                        )
    return "\n\n".join(result)


@dataclass(kw_only=True, frozen=True)
class Grade:
    """The grade to return within the mcp.grade_problem tool."""

    subscores: dict[str, float]
    weights: dict[str, float]
    metadata: dict[str, str] | None = None

    @property
    def score(self):
        assert self.subscores.keys() == self.weights.keys()
        assert np.isclose(sum(self.weights.values()), 1)
        assert min(self.subscores.values()) >= 0
        assert max(self.subscores.values()) <= 1

        score = sum(
            [self.subscores[key] * self.weights[key] for key in self.subscores.keys()]
        )
        assert score >= 0 and score <= 1

        return score


@dataclass(kw_only=True, frozen=True)
class Prompts:
    prompt: str
    image_prompts: list[str]


if __name__ == "__main__":
    generate_problems_json()
