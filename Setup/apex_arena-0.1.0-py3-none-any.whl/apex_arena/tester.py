import asyncio
from pathlib import Path
from typing import Any, Dict

from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client
from rich.console import Console

from .llm import LLMClient, LLMError
from .utils import (
    mcp_content_block_to_messages_format,
    messages_to_raw_prompt,
)

# Backward compatibility aliases
ProxyClient = LLMClient
ProxyError = LLMError

MAX_ALLOWED_TOOL_CALLS = 100


class ApexArenaClient:
    def __init__(
        self,
        server_url: str = "http://localhost:8001/mcp/",
        model: str = "starburst",
        max_tokens: int = 1000,
        enable_computer_use: bool = False,
    ):
        self.server_url = server_url
        self.model = model
        self.max_tokens = max_tokens
        self.enable_computer_use = enable_computer_use
        self.proxy = ProxyClient()

    async def run_problem(self, problem_id: str) -> Dict[str, Any]:
        async with streamablehttp_client(
            self.server_url,
            timeout=3600.0,  # 1 hour - tool-level timeouts handle actual limits
            sse_read_timeout=3600.0,
        ) as (
            read_stream,
            write_stream,
            _,
        ):
            async with ClientSession(read_stream, write_stream) as session:
                await session.initialize()

                setup_result = await session.call_tool(
                    "setup_problem", {"problem_id": problem_id}
                )

                tools = await session.list_tools()
                # Build allowed tools list based on configuration
                allowed_tools = ["bash", "str_replace_editor"]
                if self.enable_computer_use:
                    allowed_tools.append("computer")

                available_tools = [
                    {
                        "name": tool.name,
                        "description": tool.description,
                        "input_schema": tool.inputSchema,
                    }
                    for tool in tools.tools
                    if tool.name in allowed_tools
                ]
                num_tool_calls = 0

                prompt = setup_result.content[0].text
                messages = [{"role": "user", "content": prompt}]

                while True:
                    for message in messages[:-2]:
                        if message["role"] == "assistant":
                            for content in message["content"]:
                                if (
                                    isinstance(content, dict)
                                    and content.get("type") == "tool_use"
                                ):
                                    if "cache_control" in content:
                                        content["cache_control"] = None

                    # Retry logic for rate limiting
                    max_retries = 10
                    for attempt in range(max_retries + 1):
                        try:
                            response, status_code = await self.proxy.create_message(
                                model=self.model,
                                messages=messages,
                                max_tokens=self.max_tokens,
                                tools=available_tools,
                            )
                            break  # Success, exit retry loop
                        except Exception as e:
                            if (
                                attempt < max_retries
                                and "budget" not in str(e).lower()
                                and "invalid api" not in str(e).lower()
                            ):
                                # Exponential backoff: 2^attempt seconds
                                delay = min(2**attempt, 30)
                                await asyncio.sleep(delay)
                                print(f"Retrying ({attempt}/{max_retries}). error: {e}")
                                continue
                            else:
                                print(
                                    f"Errored out after {max_retries} retries. error: {e}"
                                )
                                return {
                                    "problem_id": problem_id,
                                    "grade_result": {
                                        "subscores": {"initial": 0.0},
                                        "weights": {"initial": 1.0},
                                    },
                                }

                    if response["stop_reason"] == "refusal":
                        print("Model refused to answer")
                        return {
                            "problem_id": problem_id,
                            "grade_result": {
                                "subscores": {"initial": 0.0},
                                "weights": {"initial": 1.0},
                            },
                        }
                    if response["stop_reason"] in ["max_tokens", "end_turn"]:
                        grade = await session.call_tool(
                            "grade_problem",
                            {
                                "transcript": messages_to_raw_prompt(
                                    "[system_prompt_placeholder]\n\n", messages
                                ),
                                "problem_id": problem_id,
                            },
                        )
                        return {
                            "problem_id": problem_id,
                            "grade_result": grade.content[0].text,
                        }

                    if not response.get("content"):
                        return {
                            "problem_id": problem_id,
                            "grade_result": {
                                "subscores": {"initial": 0.0},
                                "weights": {"initial": 1.0},
                                "metadata": {
                                    "feedback": "Agent might have not called grade_problem tool call!"
                                },
                            },
                        }

                    assistant_content = []
                    tool_results = []
                    has_tool_call = False
                    tool_call_idx = []

                    for idx, content in enumerate(response["content"]):
                        if content["type"] == "tool_use":
                            tool_call_idx.append(idx)

                    for idx, content in enumerate(response["content"]):
                        if content["type"] == "tool_use":
                            has_tool_call = True
                            tool_name = content["name"]
                            tool_args = content["input"]
                            tool_id = content["id"]
                            print(f"Tool name: {tool_name}")
                            print(f"Tool args: {tool_args}")

                            if tool_name == "grade_problem":
                                tool_result = await session.call_tool(
                                    tool_name, tool_args
                                )
                                return {
                                    "problem_id": problem_id,
                                    "grade_result": tool_result.content[0].text,
                                }

                            tool_result = await session.call_tool(tool_name, tool_args)
                            num_tool_calls += 1
                            print(f"Tool result: {tool_result.content[0].text}")

                            if "text" in content and content["text"]:
                                assistant_content.append(
                                    {"type": "text", "text": content["text"]}
                                )
                            assistant_content.append(
                                {
                                    "type": "tool_use",
                                    "id": content["id"],
                                    "name": content["name"],
                                    "input": content["input"],
                                    "cache_control": {"type": "ephemeral"}
                                    if idx == tool_call_idx[-1]
                                    else None,
                                }
                            )
                            tool_results.append(
                                {
                                    "type": "tool_result",
                                    "is_error": tool_result.isError,
                                    "tool_use_id": tool_id,
                                    "content": [
                                        mcp_content_block_to_messages_format(content)
                                        for content in tool_result.content
                                    ],
                                }
                            )
                        elif content["type"] == "text":
                            print(f"Text: {content['text']}")

                            if (
                                "<answer>" in content["text"]
                                and "</answer>" in content["text"]
                            ):
                                grade = await session.call_tool(
                                    "grade_problem",
                                    {
                                        "transcript": messages_to_raw_prompt(
                                            "[system_prompt_placeholder]\n\n", messages
                                        ),
                                        "problem_id": problem_id,
                                    },
                                )
                                return {
                                    "problem_id": problem_id,
                                    "grade_result": grade.content[0].text,
                                }

                            assistant_content.append(
                                {"type": "text", "text": content["text"]}
                            )
                        elif content["type"] == "thinking":
                            assistant_content.append(content)

                    messages.append({"role": "assistant", "content": assistant_content})
                    if num_tool_calls > MAX_ALLOWED_TOOL_CALLS:
                        print(f"Tool calls exceeded {MAX_ALLOWED_TOOL_CALLS}")
                        grade = await session.call_tool(
                            "grade_problem",
                            {
                                "transcript": messages_to_raw_prompt(
                                    "[system_prompt_placeholder]\n\n", messages
                                ),
                                "problem_id": problem_id,
                            },
                        )
                        return {
                            "problem_id": problem_id,
                            "grade_result": grade.content[0].text,
                        }

                    if not has_tool_call:
                        grade = await session.call_tool(
                            "grade_problem",
                            {
                                "transcript": messages_to_raw_prompt(
                                    "[system_prompt_placeholder]\n\n", messages
                                ),
                                "problem_id": problem_id,
                            },
                        )
                        return {
                            "problem_id": problem_id,
                            "grade_result": grade.content[0].text,
                        }
                    else:
                        messages.append(
                            {
                                "role": "user",
                                "content": tool_results,
                            }
                        )


async def main():
    import argparse

    parser = argparse.ArgumentParser(description="Run problems through Apex Arena")
    parser.add_argument(
        "--problem_id", default="git_wizardry", help="Problem ID to run"
    )
    parser.add_argument(
        "--server", default="http://localhost:8001/mcp/", help="MCP server URL"
    )
    parser.add_argument("--model", default="starburst", help="Model to use")
    parser.add_argument("--max_tokens", default=1000, help="Max tokens to use")
    parser.add_argument(
        "--enable-computer-use",
        action="store_true",
        help="Enable the 'computer' tool for task execution (disabled by default)",
    )
    args = parser.parse_args()

    client = ApexArenaClient(
        args.server,
        args.model,
        int(args.max_tokens),
        enable_computer_use=args.enable_computer_use,
    )
    result = await client.run_problem(args.problem_id)

    print(f"\nProblem: {result['problem_id']}")
    print("\nGrade Result:")
    print(result)


async def print_task_quality_report(problem_id: str, tasks_dir: str = "tasks"):
    """Print comprehensive quality check report for a complete task (task.yaml, grader.py, Dockerfile)."""
    from .quality_checker import QualityChecker

    console = Console()
    tasks_path = Path(tasks_dir).resolve()
    task_dir = tasks_path / problem_id

    if not task_dir.exists():
        console.print(f"[red]Task directory not found: {task_dir}[/red]")
        return

    try:
        quality_checker = QualityChecker(task_dir, "biggie")
        result = await quality_checker.check()

        console.print(
            f"\n[bold yellow]📋 Quality Check Report for {problem_id}:[/bold yellow]"
        )

        if "error" in result:
            console.print(
                f"  [red]❌ Quality check failed: {result.get('error', 'Unknown error')}[/red]"
            )
            if "raw_response" in result:
                console.print("  [dim]Raw LLM Response:[/dim]")
                console.print(f"  [dim]{result['raw_response'][:500]}...[/dim]")
        else:
            # Display formatted results
            formatted_results = quality_checker.format_results(result)
            # Split into lines and indent for display
            for line in formatted_results.split("\n"):
                if line.strip():
                    console.print(f"  {line}")

    except Exception as e:
        console.print(f"[red]Failed to run quality check on {problem_id}: {e}[/red]")


# Compatibility alias for existing code
print_task_validation_report = print_task_quality_report


if __name__ == "__main__":
    asyncio.run(main())
