import mimetypes
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urljoin

try:
    import requests
except ImportError:
    requests = None


class ApexAPIClient:
    """Client for interacting with Apex UI backend API."""

    def __init__(self, server_url: Optional[str] = None, api_key: Optional[str] = None):
        self.server_url = server_url or os.getenv(
            "APEX_SERVER_URL", "https://apex-ui-v2-319533213591.us-central1.run.app/"
        )
        self.api_key = api_key or os.getenv("APEX_API_KEY")

        if not self.server_url.endswith("/"):
            self.server_url += "/"

        if requests is None:
            raise ImportError(
                "requests library is required for API client. "
                "Install with: pip install requests"
            )

    def _get_headers(self) -> Dict[str, str]:
        """Get HTTP headers for API requests."""
        headers = {
            "Accept": "application/json",
        }

        if self.api_key:
            headers["x-api-key"] = self.api_key

        return headers

    def _make_request(self, method: str, endpoint: str, **kwargs) -> requests.Response:
        """Make HTTP request to API."""
        url = urljoin(self.server_url, endpoint)
        headers = self._get_headers()

        if "headers" in kwargs:
            headers.update(kwargs["headers"])
            del kwargs["headers"]

        response = requests.request(method, url, headers=headers, **kwargs)

        try:
            response.raise_for_status()
        except requests.HTTPError as e:
            # Try to extract error message from response body
            error_detail = str(e)
            try:
                error_data = response.json()
                if isinstance(error_data, dict):
                    # Common error message fields in API responses
                    error_message = (
                        error_data.get("error") or
                        error_data.get("message") or
                        error_data.get("detail") or
                        error_detail
                    )
                else:
                    error_message = error_detail
            except (ValueError, KeyError):
                # If response is not JSON or doesn't have expected fields,
                # try to get text response
                try:
                    error_message = response.text or error_detail
                except:
                    error_message = error_detail

            # Raise a new HTTPError with the enhanced message
            raise requests.HTTPError(
                f"{response.status_code} {response.reason}: {error_message}",
                response=response
            ) from e

        return response

    def list_tasks(self) -> List[Dict]:
        """List all tasks for authenticated user."""
        if not self.api_key:
            raise ValueError("APEX_API_KEY is required for authentication")

        response = self._make_request("GET", "api/tasks")
        return response.json()

    def _guess_mime_type(self, file_path: Path) -> str:
        """Guess MIME type from file extension."""
        mime_type, _ = mimetypes.guess_type(str(file_path))
        return mime_type or "application/octet-stream"

    def _collect_files_metadata(self, directory: Path) -> List[Dict[str, str]]:
        """Collect file paths and content types for signed URL upload."""
        files_meta = []
        for file_path in directory.rglob("*"):
            if file_path.is_file():
                relative = file_path.relative_to(directory)
                # Skip hidden files and __pycache__
                if any(p.startswith('.') or p == '__pycache__' for p in relative.parts):
                    continue
                files_meta.append({
                    "path": str(relative),
                    "contentType": self._guess_mime_type(file_path)
                })
        return files_meta

    def upload_task(
        self,
        directory: Path,
        name: str,
        spec_id: Optional[str] = None,
        task_format: Optional[str] = None,
    ) -> Dict:
        """Upload a task directory to GCS.

        By default uses signed URL upload for large files.
        Set APEX_USE_LEGACY_UPLOAD=true to use legacy multipart upload.

        Args:
            directory: Path to the task directory
            name: Task name
            spec_id: Optional specification ID to assign the task to
            task_format: Task format ("apex" or "harbor")

        Returns:
            Dict with task creation response
        """
        if not self.api_key:
            raise ValueError("APEX_API_KEY is required for authentication")

        if not directory.exists() or not directory.is_dir():
            raise ValueError(f"Directory does not exist: {directory}")

        # Check flag - default to signed URL
        use_legacy = os.getenv("APEX_USE_LEGACY_UPLOAD", "").lower() == "true"

        if use_legacy:
            return self._upload_task_legacy(directory, name, spec_id, task_format)
        else:
            return self._upload_task_signed_url(directory, name, spec_id, task_format)

    def _upload_task_signed_url(
        self, directory: Path, name: str, spec_id: Optional[str], task_format: Optional[str]
    ) -> Dict:
        """Upload using signed URLs (new method, bypasses proxy)."""
        # 1. Collect file metadata
        files_meta = self._collect_files_metadata(directory)
        if not files_meta:
            raise ValueError(f"No files found in directory: {directory}")

        # 2. Request signed URLs from server
        request_data: Dict[str, Any] = {
            "name": name,
            "files": files_meta,
            "use_signed_url": True
        }
        if spec_id:
            request_data["specId"] = spec_id
        if task_format:
            request_data["format"] = task_format

        init_response = self._make_request("POST", "api/tasks", json=request_data).json()
        task_id = init_response["taskId"]
        url_map = {u["path"]: u["url"] for u in init_response["uploadUrls"]}

        # 3. Upload each file directly to GCS
        for meta in files_meta:
            file_path = directory / meta["path"]
            signed_url = url_map[meta["path"]]
            content_type = meta.get("contentType", "application/octet-stream")

            with open(file_path, "rb") as f:
                response = requests.put(
                    signed_url,
                    data=f,
                    headers={"Content-Type": content_type}
                )
                response.raise_for_status()

        # 4. Finalize upload
        return self._make_request("POST", f"api/tasks/{task_id}/complete-upload").json()

    def _upload_task_legacy(
        self, directory: Path, name: str, spec_id: Optional[str], task_format: Optional[str]
    ) -> Dict:
        """Upload using multipart form data (legacy method)."""
        # Collect all files in directory recursively
        files_to_upload = []

        for file_path in directory.rglob("*"):
            if file_path.is_file():
                # Calculate relative path from directory root
                relative_path = file_path.relative_to(directory)
                relative_path_str = str(relative_path)

                # Skip hidden files and __pycache__
                if any(part.startswith('.') or part == '__pycache__' for part in relative_path.parts):
                    continue

                # Read file content
                with open(file_path, "rb") as f:
                    file_content = f.read()

                # Use relative path as filename
                files_to_upload.append(("files", (relative_path_str, file_content)))

        if not files_to_upload:
            raise ValueError(f"No files found in directory: {directory}")

        # Prepare form data - separate regular data from files
        data = {"name": name}

        # Add spec_id if provided
        if spec_id:
            data["specId"] = spec_id

        # Add format if provided
        if task_format:
            data["format"] = task_format

        response = self._make_request(
            "POST", "api/tasks", data=data, files=files_to_upload
        )
        return response.json()

    def get_task(self, task_id: str) -> Dict:
        """Get task information by ID."""
        if not self.api_key:
            raise ValueError("APEX_API_KEY is required for authentication")

        response = self._make_request("GET", f"api/tasks/{task_id}")
        return response.json()

    def get_spec(self, spec_id: str) -> Dict:
        """Get specification details.

        Args:
            spec_id: UUID of the specification

        Returns:
            Dict with spec information including:
                - id: Spec UUID
                - name: Spec name
                - description: Spec description
                - project_id: Associated project UUID
                - project_name: Associated project name

        Raises:
            ValueError: If APEX_API_KEY is not set
            requests.HTTPError: If spec not found (404) or unauthorized (403)
        """
        if not self.api_key:
            raise ValueError("APEX_API_KEY is required for authentication")

        response = self._make_request("GET", f"api/specs/{spec_id}")
        return response.json()

    def get_task_version(self, task_id: str) -> Dict[str, Any]:
        """Get task version information without downloading files."""
        if not self.api_key:
            raise ValueError("APEX_API_KEY is required for authentication")

        # Use the download endpoint but only extract version info from response headers/metadata
        response = self._make_request("GET", f"api/tasks/{task_id}/download")
        download_info = response.json()

        # Extract version information from response
        version_info = download_info.get("version", {})
        return {
            "task_version_id": version_info.get("version_number"),
            "version_info": version_info
        }

    def download_task(self, task_id: str) -> Dict[str, Any]:
        """Download task files and create ZIP archive locally. Returns dict with zip_content and version info."""
        if not self.api_key:
            raise ValueError("APEX_API_KEY is required for authentication")

        # Get signed URLs from the API
        response = self._make_request("GET", f"api/tasks/{task_id}/download")
        download_info = response.json()

        if "files" not in download_info:
            raise ValueError("Invalid response format from download API")

        files = download_info["files"]
        if not files:
            raise ValueError(f"No files found for task {task_id}")

        # Extract version information from response
        version_info = download_info.get("version", {})
        task_version_id = version_info.get("version_number")

        # Create ZIP archive in memory
        import io
        import zipfile

        zip_buffer = io.BytesIO()

        with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zip_file:
            for file_info in files:
                file_path = file_info["path"]
                signed_url = file_info["url"]

                try:
                    # Download file content using signed URL
                    file_response = requests.get(signed_url)
                    file_response.raise_for_status()

                    # Add to ZIP archive
                    zip_file.writestr(file_path, file_response.content)

                except Exception as e:
                    print(f"Warning: Failed to download {file_path}: {e}")
                    continue

        zip_buffer.seek(0)
        return {
            "zip_content": zip_buffer.getvalue(),
            "task_version_id": task_version_id,
            "version_info": version_info
        }

    def update_task(
        self, task_id: str, directory: Path, task_format: Optional[str] = None
    ) -> Dict:
        """Update a task by uploading new files from a directory.

        By default uses signed URL upload for large files.
        Set APEX_USE_LEGACY_UPLOAD=true to use legacy multipart upload.

        Args:
            task_id: The task ID to update
            directory: Path to the task directory with new files
            task_format: Task format ("apex" or "harbor")

        Returns:
            Dict with task update response
        """
        if not self.api_key:
            raise ValueError("APEX_API_KEY is required for authentication")

        if not directory.exists() or not directory.is_dir():
            raise ValueError(f"Directory does not exist: {directory}")

        # Check flag - default to signed URL
        use_legacy = os.getenv("APEX_USE_LEGACY_UPLOAD", "").lower() == "true"

        if use_legacy:
            return self._update_task_legacy(task_id, directory, task_format)
        else:
            return self._update_task_signed_url(task_id, directory, task_format)

    def _update_task_signed_url(
        self, task_id: str, directory: Path, task_format: Optional[str]
    ) -> Dict:
        """Update using signed URLs (new method)."""
        # 1. Collect file metadata
        files_meta = self._collect_files_metadata(directory)
        if not files_meta:
            raise ValueError(f"No files found in directory: {directory}")

        # 2. Request signed URLs from server
        request_data: Dict[str, Any] = {
            "files": files_meta,
            "use_signed_url": True
        }
        if task_format:
            request_data["format"] = task_format

        init_response = self._make_request(
            "POST", f"api/tasks/{task_id}/update", json=request_data
        ).json()
        url_map = {u["path"]: u["url"] for u in init_response["uploadUrls"]}

        # 3. Upload each file directly to GCS
        for meta in files_meta:
            file_path = directory / meta["path"]
            signed_url = url_map[meta["path"]]
            content_type = meta.get("contentType", "application/octet-stream")

            with open(file_path, "rb") as f:
                response = requests.put(
                    signed_url,
                    data=f,
                    headers={"Content-Type": content_type}
                )
                response.raise_for_status()

        # 4. Finalize update
        return self._make_request("POST", f"api/tasks/{task_id}/update/complete").json()

    def _update_task_legacy(
        self, task_id: str, directory: Path, task_format: Optional[str]
    ) -> Dict:
        """Update using multipart form data (legacy method)."""
        # Collect all files in directory recursively
        files_to_upload = []

        for file_path in directory.rglob("*"):
            if file_path.is_file():
                # Calculate relative path from directory root
                relative_path = file_path.relative_to(directory)
                relative_path_str = str(relative_path)

                # Skip hidden files and __pycache__
                if any(part.startswith('.') or part == '__pycache__' for part in relative_path.parts):
                    continue

                # Read file content
                with open(file_path, "rb") as f:
                    file_content = f.read()

                # Use relative path as filename
                files_to_upload.append(("files", (relative_path_str, file_content)))

        if not files_to_upload:
            raise ValueError(f"No files found in directory: {directory}")

        # Prepare form data - separate regular data from files
        data = {}
        if task_format:
            data["format"] = task_format

        response = self._make_request(
            "POST", f"api/tasks/{task_id}/update", data=data, files=files_to_upload
        )
        return response.json()


def get_api_client() -> ApexAPIClient:
    """Get configured API client instance."""
    return ApexAPIClient()
