import asyncio
import time
import logging
from typing import Optional

logger = logging.getLogger(__name__)


class ShellInterface:
    """
    Interface that translates Terminus2 shell commands to MCP bash tool calls.
    
    SECURITY: All commands executed through this interface run as user 1000 (model user)
    which only has access to /workdir/, preventing access to /mcp_server/ where 
    solution files may be stored. This prevents reward hacking.
    """
    
    def __init__(self, session):
        """
        Initialize shell interface with MCP session.
        
        Args:
            session: MCP ClientSession instance
        """
        self.session = session
        self.accumulated_output = ""
        
    async def send_keys(self, keystrokes: str, max_timeout_sec: float = 1.0) -> bool:
        """
        Execute keystrokes using MCP bash tool.
        
        Args:
            keystrokes: The keystrokes to execute 
            max_timeout_sec: Maximum timeout (for compatibility, not used directly)
            
        Returns:
            bool: True if timeout occurred, False otherwise
        """
        # Convert keystrokes to bash command
        # Remove trailing newline if present since bash tool doesn't need it
        command = keystrokes.rstrip('\n')
        
        if not command.strip():
            # Empty command, just wait
            await asyncio.sleep(min(max_timeout_sec, 1.0))
            return False
            
        try:
            # Execute command via MCP bash tool
            result = await self.session.call_tool(
                "bash", 
                {"command": command}
            )
            
            # Extract text content from result
            if result.content and len(result.content) > 0:
                # Concatenate all text content
                output = ""
                for content in result.content:
                    if hasattr(content, 'text') and content.text:
                        output += content.text
                
                self.accumulated_output += output
            
            return False  # No timeout occurred
            
        except Exception as e:
            logger.warning(f"Shell command failed: {command}, error: {e}")
            # Add error to output
            self.accumulated_output += f"Error executing command '{command}': {e}\n"
            return False
    
    def get_incremental_output(self) -> str:
        """
        Get the accumulated output since last call and clear it.
        
        Returns:
            str: The accumulated terminal output
        """
        output = self.accumulated_output
        self.accumulated_output = ""
        return output
    
    def capture_pane(self, capture_entire: bool = False) -> str:
        """
        Get current shell state (compatibility method).
        
        Args:
            capture_entire: Whether to capture entire history (ignored)
            
        Returns:
            str: Current accumulated output
        """
        return self.accumulated_output
    
    def is_session_alive(self) -> bool:
        """Check if session is still alive."""
        return True  # MCP sessions don't have a direct equivalent