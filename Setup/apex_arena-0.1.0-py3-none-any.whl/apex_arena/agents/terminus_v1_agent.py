import logging
import time
from typing import Any, Dict

from ..utils import messages_to_raw_prompt
from .base_agent import BaseAgent

logger = logging.getLogger(__name__)


class TerminusV1Agent(BaseAgent):
    """
    Simple terminus v1 agent using tool calling compatible with Starburst.
    Uses same tool calling pattern as MCPAgent but with starburst-compatible message formatting.
    No complex context engineering, duration handling, or advanced features.
    """

    def __init__(
        self, proxy_client, enable_computer_use=False, **kwargs
    ):
        super().__init__(**kwargs)
        self.proxy = proxy_client
        self.enable_computer_use = enable_computer_use

    async def run_problem(
        self, problem_id: str, session, logger_client=None
    ) -> Dict[str, Any]:
        """Run problem using tool calling with starburst-compatible format."""

        # Setup the problem
        setup_result = await session.call_tool(
            "setup_problem", {"problem_id": problem_id}
        )

        if logger_client:
            logger_client.log_message("SETUP", "Problem setup completed")

        # Get available tools - only bash and optionally computer
        tools = await session.list_tools()
        allowed_tools = ["bash"]
        if self.enable_computer_use:
            allowed_tools.append("computer")

        available_tools = [
            {
                "name": tool.name,
                "description": tool.description,
                "input_schema": tool.inputSchema,
            }
            for tool in tools.tools
            if tool.name in allowed_tools
        ]

        if logger_client:
            logger_client.log_message(
                "TOOLS",
                f"Available tools: {[t['name'] for t in available_tools]}",
            )

        prompt = setup_result.content[0].text
        if logger_client:
            logger_client.log_message("PROMPT", f"Initial prompt: {prompt}")

        messages = [{"role": "user", "content": prompt}]

        start_time = time.time()
        conversation_turn = 0

        while True:

            # Check max turns
            if conversation_turn > self.max_turns:
                if logger_client:
                    logger_client.log_message(
                        "ERROR", "Max turns reached, proceeding to grade"
                    )
                break

            conversation_turn += 1
            if logger_client:
                logger_client.log_message(
                    "TURN",
                    f"Starting conversation turn {conversation_turn}",
                )

            # Get model response with tools
            if logger_client:
                logger_client.log_message(
                    "DEBUG",
                    f"Calling proxy.create_message with {len(messages)} messages, {len(available_tools)} tools",
                )

            try:
                response, status_code = await self.proxy.create_message(
                    model=self.model,
                    messages=messages,
                    max_tokens=self.max_tokens,
                    tools=available_tools,
                )

                if logger_client:
                    logger_client.log_message(
                        "DEBUG", f"Got response with status {status_code}"
                    )

                if status_code != 200:
                    if logger_client:
                        logger_client.log_message(
                            "ERROR", f"HTTP {status_code}: {response}"
                        )
                    continue

            except Exception as e:
                if logger_client:
                    logger_client.log_message("ERROR", f"Model error: {e}")
                continue

            # Handle refusal
            if response.get("stop_reason") == "refusal":
                if logger_client:
                    logger_client.log_message("ERROR", "Model refused to respond")
                break

            if not response.get("content"):
                if logger_client:
                    logger_client.log_message("ERROR", "No response content from model")
                break

            # Process response content
            assistant_content = []
            tool_results = []
            has_tool_call = False

            for content in response["content"]:
                if content["type"] == "tool_use":
                    has_tool_call = True
                    tool_name = content["name"]
                    tool_args = content["input"]
                    tool_id = content["id"]

                    if logger_client:
                        logger_client.log_message(
                            "TOOL_CALL", f"{tool_name}: {tool_args}"
                        )

                    # Handle grade_problem
                    if tool_name == "grade_problem":
                        tool_result = await session.call_tool(tool_name, tool_args)
                        if logger_client:
                            logger_client.log_message(
                                "GRADE", "Problem graded successfully"
                            )
                        return {
                            "problem_id": problem_id,
                            "grade_result": tool_result.content[0].text,
                        }

                    # Handle bash tool with timeout handling
                    try:
                        tool_result = await session.call_tool(tool_name, tool_args)

                        # Check if bash tool needs restart and restart it
                        if (
                            tool_name == "bash"
                            and hasattr(tool_result, "content")
                            and tool_result.content
                            and hasattr(tool_result.content[0], "text")
                            and "tool must be restarted" in tool_result.content[0].text
                        ):
                            if logger_client:
                                logger_client.log_message(
                                    "BASH_RESTART", "Restarting bash tool"
                                )

                            # Restart the bash tool
                            await session.call_tool("bash", {"restart": True})

                            # Retry the original command
                            tool_result = await session.call_tool(tool_name, tool_args)

                    except Exception as e:
                        # Handle bash timeout or other errors gracefully
                        error_msg = str(e)
                        if tool_name == "bash" and (
                            "timed out" in error_msg or "timeout" in error_msg.lower()
                        ):
                            if logger_client:
                                logger_client.log_message(
                                    "BASH_TIMEOUT",
                                    f"Bash command timed out: {tool_args}",
                                )

                            # Create a timeout result instead of crashing
                            class MockToolResult:
                                def __init__(self):
                                    self.content = [
                                        type(
                                            "obj",
                                            (object,),
                                            {
                                                "text": f"Command timed out after exceeding the configured timeout. The command was: {tool_args.get('command', 'unknown')}"
                                            },
                                        )()
                                    ]
                                    self.isError = True

                            tool_result = MockToolResult()
                        else:
                            # Re-raise non-timeout errors
                            raise

                    if logger_client:
                        logger_client.log_message("TOOL_RESULT", str(tool_result))

                    # Add any text before tool use
                    if "text" in content and content["text"]:
                        assistant_content.append(
                            {"type": "text", "text": content["text"]}
                        )

                    # Add tool use to assistant content
                    # Include thought_signature if present (required for Gemini 3 Pro Preview)
                    tool_use_block = {
                        "type": "tool_use",
                        "id": content["id"],
                        "name": content["name"],
                        "input": content["input"],
                    }
                    if content.get("thought_signature"):
                        tool_use_block["thought_signature"] = content["thought_signature"]
                    if content.get("thought_signature_encoded") is not None:
                        tool_use_block["thought_signature_encoded"] = content["thought_signature_encoded"]
                    assistant_content.append(tool_use_block)

                    # Format tool result for starburst (simpler format)
                    tool_result_content = ""
                    if tool_result.content:
                        if hasattr(tool_result.content[0], "text"):
                            tool_result_content = tool_result.content[0].text
                        else:
                            tool_result_content = str(tool_result.content[0])

                    tool_results.append(
                        {
                            "type": "tool_result",
                            "tool_use_id": tool_id,
                            "content": tool_result_content,
                            "is_error": tool_result.isError
                            if hasattr(tool_result, "isError")
                            else False,
                        }
                    )

                elif content["type"] == "text":
                    if logger_client:
                        logger_client.log_message("MODEL_TEXT", content["text"])

                    # Check for task completion
                    if "<TASK_DONE>" in content["text"][:20]:
                        if logger_client:
                            logger_client.log_message(
                                "TASK_DONE", "Found <TASK_DONE> in model response"
                            )
                        # Grade and return
                        grade = await session.call_tool(
                            "grade_problem",
                            {
                                "transcript": messages_to_raw_prompt(
                                    "[system_prompt_placeholder]\n\n",
                                    messages,
                                ),
                                "problem_id": problem_id,
                            },
                        )
                        return {
                            "problem_id": problem_id,
                            "grade_result": grade.content[0].text,
                        }

                    assistant_content.append({"type": "text", "text": content["text"]})

            # Add assistant message
            messages.append({"role": "assistant", "content": assistant_content})

            # If no tool calls, provide guidance
            if not has_tool_call:
                if logger_client:
                    logger_client.log_message(
                        "NO_TOOLS", "No tool calls in response, providing guidance"
                    )

                # Add simple guidance message
                guidance = "Please use the bash tool to run commands, or reply with exactly '<TASK_DONE>' if you have completed the task."
                messages.append({"role": "user", "content": guidance})
            else:
                # Add tool results as user message (starburst format)
                messages.append(
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "tool_result",
                                "tool_use_id": result["tool_use_id"],
                                "content": result["content"],
                                "is_error": result["is_error"],
                            }
                            for result in tool_results
                        ],
                    }
                )

        # Final grading
        grade = await session.call_tool(
            "grade_problem",
            {
                "transcript": messages_to_raw_prompt(
                    "[system_prompt_placeholder]\n\n",
                    messages,
                ),
                "problem_id": problem_id,
            },
        )

        return {
            "problem_id": problem_id,
            "grade_result": grade.content[0].text,
        }
