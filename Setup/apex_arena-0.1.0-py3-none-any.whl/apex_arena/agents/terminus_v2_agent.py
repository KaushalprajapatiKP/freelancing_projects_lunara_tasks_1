import asyncio
import json
import logging
import time
from dataclasses import dataclass
from typing import Any, Dict, List

from ..utils import messages_to_raw_prompt
from .base_agent import BaseAgent
from .shell_interface import ShellInterface
from .terminus_json_parser import TerminusJSONParser

logger = logging.getLogger(__name__)


@dataclass
class Command:
    keystrokes: str
    duration_sec: float


PROMPT_TEMPLATE = """You are an AI assistant tasked with solving command-line tasks in a Linux environment. You will be given a task description and the output from previously executed commands. Your goal is to solve the task by providing batches of shell commands.

Format your response as JSON with the following structure:

{{
  "analysis": "Analyze the current state based on the terminal output provided. What do you see? What has been accomplished? What still needs to be done?",
  "plan": "Describe your plan for the next steps. What commands will you run and why? Be specific about what you expect each command to accomplish.",
  "commands": [
    {{
      "keystrokes": "ls -la\\n",
      "duration": 0.1
    }},
    {{
      "keystrokes": "cd project\\n",
      "duration": 0.1
    }}
  ],
  "task_complete": true
}}

Required fields:
- "analysis": Your analysis of the current situation
- "plan": Your plan for the next steps
- "commands": Array of command objects to execute

Optional fields:
- "task_complete": Boolean indicating if the task is complete (defaults to false if not present)

Command object structure:
- "keystrokes": String containing the exact keystrokes to send to the terminal (required)
- "duration": Number of seconds to wait for the command to complete before the next command will be executed (defaults to 1.0 if not present)

IMPORTANT: The text inside "keystrokes" will be used completely verbatim as keystrokes. Write commands exactly as you want them sent to the terminal:
- Most bash commands should end with a newline (\\n) to cause them to execute
- For special key sequences, use tmux-style escape sequences:
  - C-c for Ctrl+C
  - C-d for Ctrl+D

The "duration" attribute specifies the number of seconds to wait for the command to complete (default: 1.0) before the next command will be executed. On immediate tasks (e.g., cd, ls, echo, cat) set a duration of 0.1 seconds. On commands (e.g., gcc, find, rustc) set a duration of 1.0 seconds. On slow commands (e.g., make, python3 [long running script], wget [file]) set an appropriate duration as you determine necessary.

It is better to set a smaller duration than a longer duration. It is always possible to wait again if the prior output has not finished, by running {{"keystrokes": "", "duration": 10.0}} on subsequent requests to wait longer. Never wait longer than 60 seconds; prefer to poll to see intermediate result status.

Important notes:
- Each command's keystrokes are sent exactly as written to the terminal
- Do not include extra whitespace before or after the keystrokes unless it's part of the intended command
- Extra text before or after the JSON will generate warnings but be tolerated
- The JSON must be valid - use proper escaping for quotes and special characters within strings
- Commands array can be empty if you want to wait without taking action

Task Description:
{instruction}

Current terminal state:
{terminal_state}
"""

TIMEOUT_TEMPLATE = """Previous command:
{command}

The previous command timed out after {timeout_sec} seconds

It is possible that the command is not yet finished executing. If that is the case, then do nothing. It is also possible that you have entered an interactive shell and should continue sending keystrokes as normal.

Here is the current state of the terminal:

{terminal_state}"""


class TerminusV2Agent(BaseAgent):
    """
    TerminusV2-style agent adapted for MCP containers.

    SECURITY: All shell commands executed through this agent run as user 1000 (model user)
    via the MCP bash tool, which only has access to /workdir/, preventing access to
    /mcp_server/ where solution files may be stored. This prevents reward hacking.
    """

    def __init__(self, proxy_client, max_episodes: int = 1000, **kwargs):
        super().__init__(**kwargs)
        self.proxy = proxy_client
        self.parser = TerminusJSONParser()
        self.max_episodes = max_episodes
        self.pending_completion = False

    def _limit_output_length(self, output: str, max_bytes: int = 10000) -> str:
        """
        Limit output to specified byte length, keeping first and last portions.

        Args:
            output: The terminal output to potentially truncate
            max_bytes: Maximum allowed bytes (default 10000)

        Returns:
            str: Original output if under limit, or truncated with middle omitted
        """
        if len(output.encode("utf-8")) <= max_bytes:
            return output

        # Calculate portions (half each for first and last)
        portion_size = max_bytes // 2

        # Convert to bytes for accurate splitting
        output_bytes = output.encode("utf-8")

        # Get first portion
        first_portion = output_bytes[:portion_size].decode("utf-8", errors="ignore")

        # Get last portion
        last_portion = output_bytes[-portion_size:].decode("utf-8", errors="ignore")

        # Calculate omitted bytes
        omitted_bytes = (
            len(output_bytes)
            - len(first_portion.encode("utf-8"))
            - len(last_portion.encode("utf-8"))
        )

        return (
            f"{first_portion}\\n[... output limited to {max_bytes} bytes; "
            f"{omitted_bytes} interior bytes omitted ...]\\n{last_portion}"
        )

    def _get_completion_confirmation_message(self, terminal_output: str) -> str:
        """Return the task completion confirmation message."""
        return (
            f"Current terminal state:\\n{terminal_output}\\n\\n"
            "Are you sure you want to mark the task as complete? "
            "This will trigger your solution to be graded and you won't be able to "
            'make any further corrections. If so, include "task_complete": true '
            "in your JSON response again."
        )

    async def _query_llm(
        self,
        messages: List[Dict],
        prompt: str,
        logger_client=None,
    ) -> str:
        """Query the LLM with the given prompt."""
        import asyncio

        # Add current prompt to messages
        messages.append({"role": "user", "content": prompt})

        max_retries = 3
        retry_delay = 1.0  # Start with 1 second delay

        for attempt in range(max_retries):
            try:
                response, status_code = await self.proxy.create_message(
                    model=self.model,
                    messages=messages,
                    max_tokens=self.max_tokens,
                    tools=None,  # TerminusV2 doesn't use tools, just text responses
                )

                if status_code == 503:
                    # Service overloaded - retry with exponential backoff
                    if attempt < max_retries - 1:
                        logger.warning(
                            f"Service overloaded (503), retrying in {retry_delay}s (attempt {attempt + 1}/{max_retries})"
                        )
                        await asyncio.sleep(retry_delay)
                        retry_delay *= 2  # Exponential backoff
                        continue
                    else:
                        raise RuntimeError(
                            f"Service overloaded after {max_retries} attempts: {response}"
                        )

                if status_code != 200:
                    raise RuntimeError(
                        f"LLM API returned status {status_code}: {response}"
                    )

                if not response.get("content"):
                    raise RuntimeError("No content in LLM response")

                # Extract text content from response
                text_content = ""
                for content in response["content"]:
                    if content.get("type") == "text":
                        text_content += content.get("text", "")

                # Add assistant response to messages
                messages.append({"role": "assistant", "content": text_content})

                return text_content

            except Exception as e:
                if attempt < max_retries - 1 and (
                    "overloaded" in str(e).lower() or "503" in str(e)
                ):
                    logger.warning(
                        f"Retrying due to overload: {e} (attempt {attempt + 1}/{max_retries})"
                    )
                    await asyncio.sleep(retry_delay)
                    retry_delay *= 2
                    continue
                else:
                    logger.error(f"LLM query failed: {e}")
                    raise

    def _handle_llm_interaction(
        self,
        messages: List[Dict],
        prompt: str,
        logger_client=None,
    ) -> tuple[List[Command], bool, str]:
        """Handle LLM interaction and parse response."""
        # This is a coroutine but we need to run it in the async context
        response = asyncio.create_task(self._query_llm(messages, prompt, logger_client))

        # We'll need to await this in the calling context
        # For now, return a placeholder that will be handled by the caller
        return [], False, ""

    async def _execute_commands(
        self,
        commands: List[Command],
        shell: ShellInterface,
    ) -> tuple[bool, str]:
        """Execute a batch of commands in the shell.

        Args:
            commands: List of commands to execute
            shell: ShellInterface instance

        Returns:
            Tuple of (timeout_occurred, terminal_output)
        """
        timeout_occurred = False

        for command in commands:
            try:
                # Execute the command
                cmd_timeout = await shell.send_keys(
                    command.keystrokes,
                    max_timeout_sec=command.duration_sec,
                )
                if cmd_timeout:
                    timeout_occurred = True
                    break

                # Wait for the specified duration
                if command.duration_sec > 0:
                    await asyncio.sleep(min(command.duration_sec, 1.0))

            except Exception as e:
                logger.warning(f"Command execution failed: {e}")
                break

        # Get the accumulated output
        terminal_output = shell.get_incremental_output()

        if timeout_occurred:
            return True, TIMEOUT_TEMPLATE.format(
                timeout_sec=command.duration_sec,
                command=command.keystrokes,
                terminal_state=self._limit_output_length(terminal_output),
            )

        return False, self._limit_output_length(terminal_output)

    async def _run_agent_loop(
        self,
        initial_prompt: str,
        shell: ShellInterface,
        messages: List[Dict],
        logger_client=None,
    ) -> None:
        """Run the main agent loop."""
        prompt = initial_prompt

        for episode in range(self.max_episodes):
            # Check if session is still alive
            if not shell.is_session_alive():
                logger.info("Session has ended, breaking out of agent loop")
                break

            if logger_client:
                logger_client.log_message("TURN", f"Starting episode {episode}")

            # Query LLM
            try:
                response = await self._query_llm(messages, prompt, logger_client)

                if logger_client:
                    logger_client.log_message("MODEL_TEXT", response)

            except Exception as e:
                logger.error(f"LLM query failed in episode {episode}: {e}")
                break

            # Parse the response using the format-specific parser
            result = self.parser.parse_response(response)

            # Collect error/warning feedback for next prompt
            feedback = ""
            if result.error:
                feedback += f"ERROR: {result.error}"
                if result.warning:
                    feedback += f"\\nWARNINGS: {result.warning}"
            elif result.warning:
                feedback += f"WARNINGS: {result.warning}"

            # Log warnings if present
            if result.warning and logger_client:
                logger_client.log_message(
                    "PARSE_WARNING", f"Parser warnings: {result.warning}"
                )

            # Convert ParsedCommands to Commands
            commands = []
            for parsed_cmd in result.commands:
                commands.append(
                    Command(
                        keystrokes=parsed_cmd.keystrokes,
                        duration_sec=min(parsed_cmd.duration, 60),
                    )
                )

            # If there were errors, set prompt to error feedback and continue
            if feedback and "ERROR:" in feedback:
                prompt = (
                    f"Previous response had parsing errors:\\n{feedback}\\n\\n"
                    f"Please fix these issues and provide a proper JSON response."
                )
                continue

            # Execute commands
            timeout_occurred, terminal_output = await self._execute_commands(
                commands, shell
            )

            # Handle task completion with double confirmation
            if result.is_task_complete:
                if self.pending_completion:
                    # Second consecutive task complete - actually complete
                    if logger_client:
                        logger_client.log_message(
                            "TASK_COMPLETE", "Task marked as complete (confirmed)"
                        )
                    break
                else:
                    # First task complete - ask for confirmation
                    self.pending_completion = True
                    prompt = self._get_completion_confirmation_message(terminal_output)
                    continue
            else:
                # Reset pending completion if they didn't confirm
                self.pending_completion = False

            # Include warnings at top of next prompt if present
            if feedback and "WARNINGS:" in feedback:
                prompt = (
                    f"Previous response had warnings:\\n{feedback}\\n\\n"
                    f"{terminal_output}"
                )
            else:
                prompt = terminal_output

    async def run_problem(
        self, problem_id: str, session, logger_client=None
    ) -> Dict[str, Any]:
        """Run problem using TerminusV2 approach with shell commands."""

        # Setup the problem
        setup_start = time.time()
        setup_result = await session.call_tool(
            "setup_problem", {"problem_id": problem_id}
        )
        setup_duration = time.time() - setup_start
        logger.debug(f"Setup problem call_tool completed in {setup_duration:.3f}s")

        if logger_client:
            logger_client.log_message("SETUP", "Problem setup completed")

        # Initialize shell interface
        shell = ShellInterface(session)

        # Get initial terminal state
        initial_output = shell.get_incremental_output()

        prompt = json.loads(setup_result.content[0].text)

        if logger_client:
            logger_client.log_message("PROMPT", f"Initial prompt: {prompt}")

        # Create initial prompt using template
        initial_prompt = PROMPT_TEMPLATE.format(
            instruction=prompt["prompt"],
            terminal_state=self._limit_output_length(initial_output),
        )

        # Initialize message history (for conversation context)
        messages = []

        # Run the agent loop
        await self._run_agent_loop(initial_prompt, shell, messages, logger_client)

        # Grade the problem
        grade_start = time.time()
        grade = await session.call_tool(
            "grade_problem",
            {
                "transcript": messages_to_raw_prompt(
                    "[system_prompt_placeholder]\\n\\n",
                    messages,
                ),
                "problem_id": problem_id,
            },
        )
        grade_duration = time.time() - grade_start
        logger.debug(f"Grade problem call_tool completed in {grade_duration:.3f}s")

        if logger_client:
            logger_client.log_message("GRADE", "Problem graded successfully")

        return {
            "problem_id": problem_id,
            "grade_result": grade.content[0].text,
        }
