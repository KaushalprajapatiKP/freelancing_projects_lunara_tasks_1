import asyncio
import json
import logging
import time
from typing import Any, Dict, List

from ..utils import (
    mcp_content_block_to_messages_format,
    messages_to_raw_prompt,
)
from .base_agent import BaseAgent

logger = logging.getLogger(__name__)


class MCPAgent(BaseAgent):
    """
    MCP-based agent that uses bash and str_replace_editor tools.

    SECURITY: All MCP tools (bash, str_replace_editor) run as user 1000 (model user)
    which only has access to /workdir/, preventing access to /mcp_server/ where
    solution files may be stored. This prevents reward hacking.
    """

    def __init__(self, proxy_client, enable_computer_use=False, **kwargs):
        super().__init__(**kwargs)
        self.proxy = proxy_client
        self.enable_computer_use = enable_computer_use

        # Starburst-specific handling (starburst = Gemini 2.5 Pro, starburst-plus = Gemini 3 Pro Preview)
        self.is_starburst_model = self.model in ("starburst", "starburst-plus")

        if self.is_starburst_model:
            # Recitation handling
            self.recitation_count = 0
            self.max_recitation_retries = 10

            # Guidance tracking for no-tool-call scenarios
            self.consecutive_guidance_count = 0
            self.max_consecutive_guidance = 3

    def get_recitation_guidance(
        self, attempt_count: int, available_tools: List[Dict]
    ) -> str:
        """Generate progressive guidance for recitation recovery with tool-first approach."""
        tool_names = [
            tool.get("name", "") for tool in available_tools if tool.get("name")
        ]
        tool_list = ", ".join(tool_names) if tool_names else "available tools"

        base_message = "Previous response contained copyrighted content. "

        if attempt_count == 1:
            return f"{base_message}Instead of generating detailed explanations, please use the {tool_list} to: 1) Explore the current state, 2) Make specific changes, or 3) Ask for clarification about the task requirements."
        elif attempt_count == 2:
            return f"{base_message}Let's avoid lengthy explanations. Please choose ONE specific action: either use a tool from [{tool_list}] to investigate something specific, or ask a focused question about what you need to accomplish."
        else:  # Final attempt
            return f"{base_message}Final attempt: Please respond with ONLY: 1) A brief tool call with specific parameters, OR 2) A short question (1-2 sentences max) about the task requirements. Available tools: {tool_list}"

    async def run_problem(
        self, problem_id: str, session, logger_client=None
    ) -> Dict[str, Any]:
        """Run problem using MCP tools (bash, str_replace_editor)."""

        # Setup the problem
        setup_start = time.time()
        setup_result = await session.call_tool(
            "setup_problem", {"problem_id": problem_id}
        )
        setup_duration = time.time() - setup_start
        logger.debug(f"Setup problem call_tool completed in {setup_duration:.3f}s")

        if logger_client:
            logger_client.log_message("SETUP", "Problem setup completed")

        # Get available tools
        tools = await session.list_tools()

        # Build allowed tools list based on model type and configuration
        allowed_tools = ["bash"]
        if not self.is_starburst_model:
            allowed_tools.append("str_replace_editor")
        if self.enable_computer_use:
            allowed_tools.append("computer")

        available_tools = [
            {
                "name": tool.name,
                "description": tool.description,
                "input_schema": tool.inputSchema,
            }
            for tool in tools.tools
            if tool.name in allowed_tools
        ]

        if logger_client:
            logger_client.log_message(
                "TOOLS",
                f"Available tools: {[t['name'] for t in available_tools]}",
            )
        prompt = json.loads(setup_result.content[0].text)

        if logger_client:
            logger_client.log_message("PROMPT", f"Initial prompt: {prompt}")

        messages = [
            {
                "role": "user",
                "content": [
                    {
                        "type": "image",
                        "source": {
                            "data": image_prompt,
                            "media_type": "image/jpeg",
                            "type": "base64",
                        },
                    }
                    for image_prompt in prompt["image_prompts"]
                ]
                + [
                    {
                        "type": "text",
                        "text": prompt["prompt"],
                    }
                ],
            },
        ]

        conversation_turn = 0
        while True:
            # Clear cache control from old messages
            for message in messages[:-2]:
                if message["role"] == "assistant":
                    for content in message["content"]:
                        if (
                            isinstance(content, dict)
                            and content.get("type") == "tool_use"
                        ):
                            tool_use_content = content
                            if "cache_control" in tool_use_content:
                                tool_use_content["cache_control"] = None

            if conversation_turn > self.max_turns:
                if logger_client:
                    logger_client.log_message("ERROR", "Max turns reached, exiting")
                grade_start = time.time()
                grade = await session.call_tool(
                    "grade_problem",
                    {
                        "transcript": messages_to_raw_prompt(
                            "[system_prompt_placeholder]\n\n",
                            messages,
                        ),
                        "problem_id": problem_id,
                    },
                )
                grade_duration = time.time() - grade_start
                logger.debug(
                    f"Grade problem call_tool (max turns) completed in {grade_duration:.3f}s"
                )
                return {
                    "problem_id": problem_id,
                    "grade_result": grade.content[0].text,
                }

            conversation_turn += 1
            if logger_client:
                logger_client.log_message(
                    "TURN",
                    f"Starting conversation turn {conversation_turn}",
                )

            # Retry logic for rate limiting
            max_retries = 3
            for attempt in range(max_retries + 1):
                try:
                    create_message_start = time.time()
                    response, status_code = await self.proxy.create_message(
                        model=self.model,
                        messages=messages,
                        max_tokens=self.max_tokens,
                        tools=available_tools,
                    )
                    create_message_duration = time.time() - create_message_start
                    logger.debug(
                        f"Create message completed in {create_message_duration:.3f}s"
                    )
                    break  # Success, exit retry loop
                except Exception as e:
                    error_str = str(e).lower()

                    # Check if this is a recitation error that should be handled with guidance (starburst only)
                    if self.is_starburst_model and "recitation" in error_str:
                        self.recitation_count += 1

                        if self.recitation_count <= self.max_recitation_retries:
                            guidance_message = self.get_recitation_guidance(
                                self.recitation_count, available_tools
                            )

                            if logger_client:
                                logger_client.log_message(
                                    "RECITATION_RECOVERY",
                                    f"Exception-based recitation attempt {self.recitation_count}/{self.max_recitation_retries}: {guidance_message}",
                                )

                            # Add guidance to conversation and break retry loop to continue with guidance
                            messages.append(
                                {"role": "user", "content": guidance_message}
                            )
                            break  # Exit retry loop, continue conversation with guidance
                        else:
                            # Max recitation retries reached
                            if logger_client:
                                logger_client.log_message(
                                    "ERROR",
                                    "Max recitation retries reached via exception, proceeding to grade",
                                )
                            guidance_message = "Unable to generate appropriate response after multiple attempts. Please provide your final answer or use available tools."
                            messages.append(
                                {"role": "user", "content": guidance_message}
                            )
                            break  # Exit retry loop, continue conversation

                    # Handle other retry-able errors
                    elif (
                        attempt < max_retries
                        and "budget" not in error_str
                        and "invalid api" not in error_str
                    ):
                        # Exponential backoff: 2^attempt seconds
                        delay = min(2**attempt, 30)
                        await asyncio.sleep(delay)
                        if logger_client:
                            logger_client.log_message(
                                "RETRY",
                                f"Retrying ({attempt}/{max_retries}). error: {e}",
                            )
                        continue
                    else:
                        if logger_client:
                            logger_client.log_message(
                                "ERROR",
                                f"Errored out after {max_retries} retries. error: {e}",
                            )
                        raise

            # Check if we broke out of retry loop due to recitation guidance (starburst only)
            # In that case, response might not be defined, so continue to next iteration
            if self.is_starburst_model and "response" not in locals():
                continue

            # Handle non-200 status codes (especially 500 for conversion errors)
            if status_code != 200:
                if self.is_starburst_model and status_code == 500:
                    # Check for conversion_failed errors with stop_reason
                    error_type_from_proxy = response.get("error", "unknown")
                    if error_type_from_proxy == "conversion_failed":
                        finish_reason = response.get("stop_reason", "UNKNOWN")
                        error_message = response.get(
                            "message", "Unknown conversion error"
                        )

                        if logger_client:
                            logger_client.log_message(
                                "ERROR",
                                f"Conversion error (500): {error_message} :: Detected finish_reason: {finish_reason}",
                            )

                        # Use the finish_reason for guidance logic
                        if finish_reason == "RECITATION":
                            self.recitation_count += 1

                            if self.recitation_count <= self.max_recitation_retries:
                                guidance_message = self.get_recitation_guidance(
                                    self.recitation_count, available_tools
                                )

                                if logger_client:
                                    logger_client.log_message(
                                        "RECITATION_RECOVERY",
                                        f"Status 500 recitation attempt {self.recitation_count}/{self.max_recitation_retries}: {guidance_message}",
                                    )

                                # Add guidance to conversation and continue
                                messages.append(
                                    {"role": "user", "content": guidance_message}
                                )
                                continue
                            else:
                                # Max retries reached - proceed to grading
                                if logger_client:
                                    logger_client.log_message(
                                        "ERROR",
                                        "Max recitation retries reached via status 500, proceeding to grade",
                                    )
                                guidance_message = "Unable to generate appropriate response after multiple attempts. Please provide your final answer or use available tools."
                                messages.append(
                                    {"role": "user", "content": guidance_message}
                                )
                                continue

                        # Handle other finish_reasons from status 500
                        elif finish_reason == "SAFETY":
                            guidance_message = "The previous response was blocked due to safety concerns. Please try to respond differently, avoiding potentially problematic content."
                        elif finish_reason == "MAX_TOKENS":
                            guidance_message = "The previous response exceeded the token limit. Please use fewer tokens in your response."
                        else:
                            guidance_message = "There was an issue with the previous response. Please try again with a relevant tool call or provide your final answer."

                        if finish_reason != "RECITATION":  # Already handled above
                            if logger_client:
                                logger_client.log_message(
                                    "GUIDANCE",
                                    f"Status 500 finish reason: {finish_reason} - {guidance_message}",
                                )

                            # Add guidance message to conversation
                            messages.append(
                                {"role": "user", "content": guidance_message}
                            )
                        continue

                # For non-500 errors or non-starburst models, log and continue with existing logic
                error_message = response.get("message", f"HTTP {status_code} error")
                if logger_client:
                    logger_client.log_message(
                        "ERROR", f"HTTP {status_code}: {error_message}"
                    )
                # Let existing retry logic handle this
                continue

            # Handle refusal cases from model
            if response.get("stop_reason") == "refusal":
                if logger_client:
                    logger_client.log_message(
                        "ERROR", "Model refused to respond (safety/content filter)"
                    )
                grade_start = time.time()
                grade = await session.call_tool(
                    "grade_problem",
                    {
                        "transcript": messages_to_raw_prompt(
                            "[system_prompt_placeholder]\n\n",
                            messages,
                        ),
                        "problem_id": problem_id,
                    },
                )
                grade_duration = time.time() - grade_start
                logger.debug(
                    f"Grade problem call_tool (refusal) completed in {grade_duration:.3f}s"
                )
                return {
                    "problem_id": problem_id,
                    "grade_result": grade.content[0].text,
                }

            if not response.get("content"):
                if logger_client:
                    logger_client.log_message("ERROR", "No response content from model")
                grade_start = time.time()
                grade = await session.call_tool(
                    "grade_problem",
                    {
                        "transcript": messages_to_raw_prompt(
                            "[system_prompt_placeholder]\n\n",
                            messages,
                        ),
                        "problem_id": problem_id,
                    },
                )
                grade_duration = time.time() - grade_start
                logger.debug(
                    f"Grade problem call_tool (no content) completed in {grade_duration:.3f}s"
                )
                return {
                    "problem_id": problem_id,
                    "grade_result": grade.content[0].text,
                }

            assistant_content = []
            tool_results = []
            has_tool_call = False
            tool_call_idx = []

            for idx, content in enumerate(response["content"]):
                if content["type"] == "tool_use":
                    tool_call_idx.append(idx)

            for idx, content in enumerate(response["content"]):
                if content["type"] == "tool_use":
                    has_tool_call = True
                    # Reset guidance counter since model made a tool call (starburst only)
                    if self.is_starburst_model:
                        self.consecutive_guidance_count = 0
                    tool_name = content["name"]
                    tool_args = content["input"]
                    tool_id = content["id"]

                    if logger_client:
                        logger_client.log_message(
                            "TOOL_CALL", f"{tool_name}: {tool_args}"
                        )

                    if tool_name == "grade_problem":
                        tool_start = time.time()
                        tool_result = await session.call_tool(tool_name, tool_args)
                        tool_duration = time.time() - tool_start
                        logger.debug(
                            f"Grade problem call_tool completed in {tool_duration:.3f}s"
                        )
                        if logger_client:
                            logger_client.log_message(
                                "GRADE", "Problem graded successfully"
                            )
                        return {
                            "problem_id": problem_id,
                            "grade_result": tool_result.content[0].text,
                        }

                    tool_start = time.time()
                    tool_result = await session.call_tool(tool_name, tool_args)
                    tool_duration = time.time() - tool_start
                    logger.debug(
                        f"Tool {tool_name} call_tool completed in {tool_duration:.3f}s"
                    )
                    if logger_client:
                        logger_client.log_message(
                            "TOOL_RESULT",
                            str(tool_result),
                        )

                    if "text" in content and content["text"]:
                        assistant_content.append(
                            {"type": "text", "text": content["text"]}
                        )
                    
                    # Build tool_use content, preserving thought_signature for Gemini 3 Pro Preview
                    tool_use_content = {
                        "type": "tool_use",
                        "id": content["id"],
                        "name": content["name"],
                        "input": content["input"],
                        "cache_control": {"type": "ephemeral"}
                        if idx == tool_call_idx[-1]
                        else None,
                    }
                    
                    # Preserve thought_signature if present (required for Gemini 3 Pro Preview)
                    if "thought_signature" in content:
                        tool_use_content["thought_signature"] = content["thought_signature"]
                    if "thought_signature_encoded" in content:
                        tool_use_content["thought_signature_encoded"] = content["thought_signature_encoded"]
                    
                    assistant_content.append(tool_use_content)
                    tool_results.append(
                        {
                            "type": "tool_result",
                            "is_error": tool_result.isError,
                            "tool_use_id": tool_id,
                            "content": [
                                mcp_content_block_to_messages_format(content)
                                for content in tool_result.content
                            ],
                        }
                    )
                elif content["type"] == "text":
                    if logger_client:
                        logger_client.log_message(
                            "MODEL_TEXT",
                            content["text"],
                        )

                    if "<TASK_DONE>" in content["text"][:20]:
                        logger.debug(f"found <TASK_DONE>. finished problem {problem_id}")
                        if logger_client:
                            logger_client.log_message(
                                "TASK_DONE",
                                "Found <TASK_DONE> in model response",
                            )
                        # Reset guidance counter since model provided <TASK_DONE> (starburst only)
                        if self.is_starburst_model:
                            self.consecutive_guidance_count = 0
                        grade_start = time.time()
                        grade = await session.call_tool(
                            "grade_problem",
                            {
                                "transcript": messages_to_raw_prompt(
                                    "[system_prompt_placeholder]\n\n",
                                    messages,
                                ),
                                "problem_id": problem_id,
                            },
                        )
                        grade_duration = time.time() - grade_start
                        logger.debug(
                            f"Grade problem call_tool (answer found) completed in {grade_duration:.3f}s"
                        )
                        return {
                            "problem_id": problem_id,
                            "grade_result": grade.content[0].text,
                        }

                    assistant_content.append({"type": "text", "text": content["text"]})
                elif content["type"] == "thinking":
                    if logger_client:
                        logger_client.log_message(
                            "THINKING",
                            f"Thinking: {content['thinking']}",
                        )
                    assistant_content.append(content)

            messages.append({"role": "assistant", "content": assistant_content})
            if not has_tool_call:
                if self.is_starburst_model:
                    # Starburst-specific handling: Check for answer tags and provide guidance
                    has_answer_or_done = False
                    for content in assistant_content:
                        if content.get("type") == "text":
                            text = content.get("text", "")
                            if (
                                "<TASK_DONE>" in text[:20]
                            ):
                                has_answer_or_done = True
                                break

                    if has_answer_or_done:
                        # This should not happen as answer tags are handled above,
                        # but just in case, grade the response
                        if logger_client:
                            logger_client.log_message(
                                "NO_TOOLS",
                                "No tool calls in response but found answer tags, grading final state",
                            )
                        grade_start = time.time()
                        grade = await session.call_tool(
                            "grade_problem",
                            {
                                "transcript": messages_to_raw_prompt(
                                    "[system_prompt_placeholder]\n\n", messages
                                ),
                                "problem_id": problem_id,
                            },
                        )
                        grade_duration = time.time() - grade_start
                        logger.debug(
                            f"Grade problem call_tool (no tools but answer found) completed in {grade_duration:.3f}s"
                        )
                        return {
                            "problem_id": problem_id,
                            "grade_result": grade.content[0].text,
                        }
                    else:
                        # No tool calls and no answer tags - check guidance counter
                        self.consecutive_guidance_count += 1

                        if (
                            self.consecutive_guidance_count
                            <= self.max_consecutive_guidance
                        ):
                            # Provide guidance
                            if logger_client:
                                logger_client.log_message(
                                    "NO_TOOLS",
                                    f"No tool calls and no answer tags in response, providing guidance ({self.consecutive_guidance_count}/{self.max_consecutive_guidance})",
                                )
                            guidance_message = "Please respond with a tool call, or reply with exactly '<TASK_DONE>' if no tool call is needed and you have completed the task."

                            # Add guidance message to conversation and continue
                            messages.append(
                                {"role": "user", "content": guidance_message}
                            )
                            continue
                        else:
                            # Max guidance reached - proceed to grading
                            if logger_client:
                                logger_client.log_message(
                                    "NO_TOOLS",
                                    f"Max consecutive guidance ({self.max_consecutive_guidance}) reached, proceeding to grade",
                                )
                            grade_start = time.time()
                            grade = await session.call_tool(
                                "grade_problem",
                                {
                                    "transcript": messages_to_raw_prompt(
                                        "[system_prompt_placeholder]\n\n", messages
                                    ),
                                    "problem_id": problem_id,
                                },
                            )
                            grade_duration = time.time() - grade_start
                            logger.debug(
                                f"Grade problem call_tool (max guidance reached) completed in {grade_duration:.3f}s"
                            )
                            return {
                                "problem_id": problem_id,
                                "grade_result": grade.content[0].text,
                            }
                else:
                    if logger_client:
                        logger_client.log_message(
                            "NO_TOOLS",
                            "No tool calls in response, grading final state",
                        )
                    grade_start = time.time()
                    grade = await session.call_tool(
                        "grade_problem",
                        {
                            "transcript": messages_to_raw_prompt(
                                "[system_prompt_placeholder]\n\n", messages
                            ),
                            "problem_id": problem_id,
                        },
                    )
                    grade_duration = time.time() - grade_start
                    logger.debug(
                        f"Grade problem call_tool (no tools) completed in {grade_duration:.3f}s"
                    )
                    logger.debug(f"no tool call. finished problem {problem_id}")
                    return {
                        "problem_id": problem_id,
                        "grade_result": grade.content[0].text,
                    }
            else:
                messages.append(
                    {
                        "role": "user",
                        "content": tool_results,
                    }
                )
