"""Format registry for task format adapters.

This module provides a central registry for all task format adapters,
allowing dynamic registration and lookup of format handlers.
"""

from typing import Dict, List, Type

from .base import TaskFormatAdapter


class FormatRegistry:
    """Registry for task format adapters.

    This class maintains a mapping of format names to adapter classes,
    providing a central point for format registration and lookup.

    Usage:
        # Register a format
        FormatRegistry.register("apex", ApexFormatAdapter)

        # Get an adapter instance
        adapter = FormatRegistry.get_adapter("apex")

        # List available formats
        formats = FormatRegistry.list_formats()  # ["apex", "harbor"]
    """

    _adapters: Dict[str, Type[TaskFormatAdapter]] = {}
    _default_format: str = "apex"

    @classmethod
    def register(cls, name: str, adapter_class: Type[TaskFormatAdapter]) -> None:
        """Register a format adapter.

        Args:
            name: The format identifier (e.g., "apex", "harbor")
            adapter_class: The adapter class to register
        """
        cls._adapters[name] = adapter_class

    @classmethod
    def get_adapter(cls, format_name: str = None) -> TaskFormatAdapter:
        """Get an instance of the specified format adapter.

        Args:
            format_name: The format to get (defaults to "apex")

        Returns:
            An instance of the requested format adapter

        Raises:
            ValueError: If the format is not registered
        """
        name = format_name or cls._default_format
        if name not in cls._adapters:
            available = list(cls._adapters.keys())
            raise ValueError(f"Unknown format: {name}. Available formats: {available}")
        return cls._adapters[name]()

    @classmethod
    def list_formats(cls) -> List[str]:
        """List all registered format names.

        Returns:
            List of registered format identifiers
        """
        return list(cls._adapters.keys())

    @classmethod
    def is_registered(cls, format_name: str) -> bool:
        """Check if a format is registered.

        Args:
            format_name: The format identifier to check

        Returns:
            True if the format is registered, False otherwise
        """
        return format_name in cls._adapters

    @classmethod
    def get_default_format(cls) -> str:
        """Get the default format name.

        Returns:
            The default format identifier ("apex")
        """
        return cls._default_format

    @classmethod
    def set_default_format(cls, format_name: str) -> None:
        """Set the default format.

        Args:
            format_name: The format to set as default

        Raises:
            ValueError: If the format is not registered
        """
        if format_name not in cls._adapters:
            available = list(cls._adapters.keys())
            raise ValueError(f"Cannot set default to unknown format: {format_name}. Available: {available}")
        cls._default_format = format_name
