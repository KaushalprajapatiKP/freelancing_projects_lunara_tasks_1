"""Task format adapters for Apex Arena.

This module provides a unified interface for handling multiple task formats:
- apex: Original Apex Arena format (task.yaml + grader.py)
- harbor: Harbor framework format (task.toml + instruction.md)

Usage:
    from apex_arena.task_formats import FormatRegistry

    # Get an adapter for a specific format
    adapter = FormatRegistry.get_adapter("apex")

    # Check if a directory contains a valid task
    if adapter.is_valid_task(task_dir):
        task_info = adapter.load_task(task_id, base_dir)

    # List available formats
    formats = FormatRegistry.list_formats()  # ["apex", "harbor"]
"""

from .apex_adapter import ApexFormatAdapter
from .base import GradingResultUnified, TaskFormatAdapter, TaskInfo
from .harbor_adapter import HarborFormatAdapter
from .registry import FormatRegistry

# Register format adapters
FormatRegistry.register("apex", ApexFormatAdapter)
FormatRegistry.register("harbor", HarborFormatAdapter)

__all__ = [
    # Base classes and types
    "TaskFormatAdapter",
    "TaskInfo",
    "GradingResultUnified",
    # Registry
    "FormatRegistry",
    # Adapters
    "ApexFormatAdapter",
    "HarborFormatAdapter",
]
