"""Harbor ATIF trajectory parser.

This module parses Harbor's ATIF (Agent Trajectory Interchange Format) trajectory.json
files and converts them to the apex-ui messages format for storage and visualization.

ATIF Specification: https://harborframework.com/docs/trajectory-format
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional


@dataclass
class HarborToolCall:
    """A tool call in a Harbor trajectory step."""

    tool_call_id: str
    function_name: str
    arguments: Dict[str, Any] = field(default_factory=dict)


@dataclass
class HarborObservationResult:
    """A single observation result from a tool execution."""

    source_call_id: str
    content: str


@dataclass
class HarborObservation:
    """Observation (tool output) in a Harbor trajectory step."""

    results: List[HarborObservationResult] = field(default_factory=list)


@dataclass
class HarborMetrics:
    """Per-step metrics from Harbor trajectory."""

    prompt_tokens: Optional[int] = None
    completion_tokens: Optional[int] = None
    cached_tokens: Optional[int] = None
    cost_usd: Optional[float] = None


@dataclass
class HarborStep:
    """A single step in a Harbor trajectory."""

    step_id: int
    timestamp: str
    source: str  # "user", "agent", or "system"
    message: Optional[str] = None
    reasoning_content: Optional[str] = None
    tool_calls: List[HarborToolCall] = field(default_factory=list)
    observation: Optional[HarborObservation] = None
    metrics: Optional[HarborMetrics] = None
    model_name: Optional[str] = None


@dataclass
class HarborAgent:
    """Agent metadata from Harbor trajectory."""

    name: str
    version: Optional[str] = None
    model_name: Optional[str] = None
    extra: Optional[Dict[str, Any]] = None


@dataclass
class HarborFinalMetrics:
    """Final aggregate metrics from Harbor trajectory."""

    total_prompt_tokens: Optional[int] = None
    total_completion_tokens: Optional[int] = None
    total_cached_tokens: Optional[int] = None
    total_cost_usd: Optional[float] = None
    total_steps: Optional[int] = None


@dataclass
class HarborTrajectory:
    """Root trajectory object from Harbor ATIF format."""

    schema_version: str
    session_id: str
    agent: HarborAgent
    steps: List[HarborStep]
    notes: Optional[str] = None
    final_metrics: Optional[HarborFinalMetrics] = None
    continued_trajectory_ref: Optional[str] = None
    extra: Optional[Dict[str, Any]] = None


def parse_tool_call(data: Dict[str, Any]) -> HarborToolCall:
    """Parse a tool call from raw dictionary."""
    return HarborToolCall(
        tool_call_id=data.get("tool_call_id", ""),
        function_name=data.get("function_name", ""),
        arguments=data.get("arguments", {}),
    )


def parse_observation_result(data: Dict[str, Any]) -> HarborObservationResult:
    """Parse an observation result from raw dictionary."""
    return HarborObservationResult(
        source_call_id=data.get("source_call_id", ""),
        content=data.get("content", ""),
    )


def parse_observation(data: Optional[Dict[str, Any]]) -> Optional[HarborObservation]:
    """Parse observation from raw dictionary."""
    if data is None:
        return None
    results = [parse_observation_result(r) for r in data.get("results", [])]
    return HarborObservation(results=results)


def parse_metrics(data: Optional[Dict[str, Any]]) -> Optional[HarborMetrics]:
    """Parse metrics from raw dictionary."""
    if data is None:
        return None
    return HarborMetrics(
        prompt_tokens=data.get("prompt_tokens"),
        completion_tokens=data.get("completion_tokens"),
        cached_tokens=data.get("cached_tokens"),
        cost_usd=data.get("cost_usd"),
    )


def parse_step(data: Dict[str, Any]) -> HarborStep:
    """Parse a trajectory step from raw dictionary."""
    tool_calls = [parse_tool_call(tc) for tc in data.get("tool_calls", [])]
    observation = parse_observation(data.get("observation"))
    metrics = parse_metrics(data.get("metrics"))

    return HarborStep(
        step_id=data.get("step_id", 0),
        timestamp=data.get("timestamp", ""),
        source=data.get("source", "agent"),
        message=data.get("message"),
        reasoning_content=data.get("reasoning_content"),
        tool_calls=tool_calls,
        observation=observation,
        metrics=metrics,
        model_name=data.get("model_name"),
    )


def parse_agent(data: Dict[str, Any]) -> HarborAgent:
    """Parse agent metadata from raw dictionary."""
    return HarborAgent(
        name=data.get("name", ""),
        version=data.get("version"),
        model_name=data.get("model_name"),
        extra=data.get("extra"),
    )


def parse_final_metrics(
    data: Optional[Dict[str, Any]],
) -> Optional[HarborFinalMetrics]:
    """Parse final metrics from raw dictionary."""
    if data is None:
        return None
    return HarborFinalMetrics(
        total_prompt_tokens=data.get("total_prompt_tokens"),
        total_completion_tokens=data.get("total_completion_tokens"),
        total_cached_tokens=data.get("total_cached_tokens"),
        total_cost_usd=data.get("total_cost_usd"),
        total_steps=data.get("total_steps"),
    )


def parse_trajectory(data: Dict[str, Any]) -> HarborTrajectory:
    """Parse a complete Harbor trajectory from raw dictionary.

    Args:
        data: Raw dictionary from trajectory.json

    Returns:
        HarborTrajectory dataclass with all parsed data
    """
    agent = parse_agent(data.get("agent", {}))
    steps = [parse_step(s) for s in data.get("steps", [])]
    final_metrics = parse_final_metrics(data.get("final_metrics"))

    return HarborTrajectory(
        schema_version=data.get("schema_version", "ATIF-v1.5"),
        session_id=data.get("session_id", ""),
        agent=agent,
        steps=steps,
        notes=data.get("notes"),
        final_metrics=final_metrics,
        continued_trajectory_ref=data.get("continued_trajectory_ref"),
        extra=data.get("extra"),
    )


def _source_to_role(source: str) -> str:
    """Convert ATIF source to OpenAI-style role.

    Args:
        source: ATIF source ("user", "agent", "system")

    Returns:
        Role string ("user", "assistant", "system")
    """
    if source == "agent":
        return "assistant"
    return source  # "user" and "system" map directly


def _tool_call_to_dict(tool_call: HarborToolCall) -> Dict[str, Any]:
    """Convert tool call to serializable dict."""
    return {
        "tool_call_id": tool_call.tool_call_id,
        "function_name": tool_call.function_name,
        "arguments": tool_call.arguments,
    }


def _observation_to_dict(observation: Optional[HarborObservation]) -> Optional[Dict[str, Any]]:
    """Convert observation to serializable dict."""
    if observation is None:
        return None
    return {
        "results": [
            {"source_call_id": r.source_call_id, "content": r.content}
            for r in observation.results
        ]
    }


def _metrics_to_dict(metrics: Optional[HarborMetrics]) -> Optional[Dict[str, Any]]:
    """Convert metrics to serializable dict, excluding None values."""
    if metrics is None:
        return None
    result = {}
    if metrics.prompt_tokens is not None:
        result["prompt_tokens"] = metrics.prompt_tokens
    if metrics.completion_tokens is not None:
        result["completion_tokens"] = metrics.completion_tokens
    if metrics.cached_tokens is not None:
        result["cached_tokens"] = metrics.cached_tokens
    if metrics.cost_usd is not None:
        result["cost_usd"] = metrics.cost_usd
    return result if result else None


def trajectory_to_messages(trajectory: HarborTrajectory) -> List[Dict[str, Any]]:
    """Convert a Harbor trajectory to apex-ui messages format.

    Each step produces 1-2 messages:
    - Message 1: Assistant/User/System message with content + tool_calls in content_json
    - Message 2: Observation message (if observation exists) with role="observation"

    No metrics are uploaded - they're not needed for visualization.
    No "format": "harbor" field - task already has format info.

    Args:
        trajectory: Parsed HarborTrajectory object

    Returns:
        List of message dictionaries ready for apex-ui API
    """
    messages = []
    seq = 1

    for step in trajectory.steps:
        # Message 1: Main content + tool calls
        content_json: Dict[str, Any] = {}

        # Add reasoning if present
        if step.reasoning_content:
            content_json["reasoning"] = step.reasoning_content

        # Add tool calls if present
        if step.tool_calls:
            content_json["tool_calls"] = [
                _tool_call_to_dict(tc) for tc in step.tool_calls
            ]

        messages.append({
            "timestamp": step.timestamp,
            "sequence_number": seq,
            "role": _source_to_role(step.source),
            "content": step.message or "",
            "content_json": content_json if content_json else None,
        })
        seq += 1

        # Message 2: Observation (if exists) - use "tool" role
        if step.observation and step.observation.results:
            obs_content = "\n".join(r.content for r in step.observation.results)
            messages.append({
                "timestamp": step.timestamp,
                "sequence_number": seq,
                "role": "tool",
                "content": obs_content,
                "content_json": None,
            })
            seq += 1

    return messages


def parse_trajectory_to_messages(trajectory_data: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Convenience function to parse raw trajectory JSON and convert to messages.

    This combines parse_trajectory() and trajectory_to_messages() into a single call.

    Args:
        trajectory_data: Raw dictionary from trajectory.json

    Returns:
        List of message dictionaries ready for apex-ui API

    Example:
        >>> import json
        >>> with open("trajectory.json") as f:
        ...     data = json.load(f)
        >>> messages = parse_trajectory_to_messages(data)
        >>> # POST messages to /api/evaluations/{evalId}/rollouts/{rolloutId}/messages
    """
    trajectory = parse_trajectory(trajectory_data)
    return trajectory_to_messages(trajectory)
