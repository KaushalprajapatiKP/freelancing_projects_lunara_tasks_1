"""Base classes and types for task format adapters.

This module defines the abstract interface that all task format adapters must implement,
along with unified data structures for task metadata and grading results.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional


@dataclass
class TaskInfo:
    """Unified task metadata across all formats.

    Attributes:
        task_id: Unique identifier for the task
        prompt: The task prompt/instruction text
        image_prompts: List of base64-encoded images (if applicable)
        metadata: Format-specific metadata dictionary
        format_type: The format type (e.g., "apex", "harbor")
        dockerfile_path: Path to the task's Dockerfile (if exists)
        task_dir: Path to the task directory
    """

    task_id: str
    prompt: str
    image_prompts: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    format_type: str = "apex"
    dockerfile_path: Optional[Path] = None
    task_dir: Optional[Path] = None


@dataclass
class GradingResultUnified:
    """Unified grading result across all formats.

    This normalizes the different grading output formats:
    - Apex: GradingResult with subscores, weights, feedback
    - Harbor: reward.txt (single score) or reward.json (metrics)

    Attributes:
        score: Overall score (0.0 to 1.0 typically)
        subscores: Dictionary of individual score components
        weights: Dictionary of weights for each subscore
        feedback: Human-readable feedback string
        details: Additional details/metadata from grading
    """

    score: float
    subscores: Dict[str, float] = field(default_factory=dict)
    weights: Dict[str, float] = field(default_factory=dict)
    feedback: Optional[str] = None
    details: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation.

        Note: feedback is placed under "metadata" key for consistency with
        the apex Grade class and UI expectations.
        """
        result = {
            "score": self.score,
            "subscores": self.subscores,
            "weights": self.weights,
        }
        # Put feedback under metadata key (consistent with apex Grade class)
        if self.feedback or self.details:
            metadata = {}
            if self.feedback:
                metadata["feedback"] = self.feedback
            if self.details:
                metadata.update(self.details)
            result["metadata"] = metadata
        return result


class TaskFormatAdapter(ABC):
    """Abstract base class for task format adapters.

    Each format adapter handles the specifics of a particular task format:
    - Task discovery (finding valid tasks in a directory)
    - Task loading (parsing config files, loading prompts)
    - Grading (executing graders and collecting results)

    Implementations:
    - ApexFormatAdapter: Original Apex Arena format (task.yaml + grader.py)
    - HarborFormatAdapter: Harbor framework format (task.toml + instruction.md)
    """

    @property
    @abstractmethod
    def format_name(self) -> str:
        """Return the format identifier (e.g., 'apex', 'harbor')."""
        pass

    @abstractmethod
    def is_valid_task(self, task_dir: Path) -> bool:
        """Check if a directory contains a valid task in this format.

        Args:
            task_dir: Path to the potential task directory

        Returns:
            True if the directory contains a valid task, False otherwise
        """
        pass

    @abstractmethod
    def discover_tasks(self, base_dir: Path) -> List[str]:
        """Discover all valid tasks in the given directory.

        Args:
            base_dir: Base directory containing task subdirectories

        Returns:
            List of task IDs (directory names) that are valid tasks
        """
        pass

    @abstractmethod
    def load_task(self, task_id: str, base_dir: Path) -> TaskInfo:
        """Load task metadata and prompt.

        Args:
            task_id: The task identifier (directory name)
            base_dir: Base directory containing the task

        Returns:
            TaskInfo with loaded metadata and prompt
        """
        pass

    @abstractmethod
    async def run_and_grade(
        self,
        task_id: str,
        task_dir: Path,
        model: str,
        agent: str,
        **kwargs,
    ) -> GradingResultUnified:
        """Execute the task and grade the result.

        For Apex format: This is called after the rollout with the transcript.
        For Harbor format: This delegates to `harbor run` CLI.

        Args:
            task_id: The task identifier
            task_dir: Path to the task directory
            model: Model identifier to use
            agent: Agent type to use
            **kwargs: Additional format-specific arguments
                - transcript: (Apex) The conversation transcript for grading

        Returns:
            GradingResultUnified with the grading result
        """
        pass

    @abstractmethod
    def get_dockerfile_path(self, task_id: str, base_dir: Path) -> Optional[Path]:
        """Return the path to the task's Dockerfile.

        Args:
            task_id: The task identifier
            base_dir: Base directory containing the task

        Returns:
            Path to Dockerfile if it exists, None otherwise
        """
        pass

    def get_timeout(self, task_info: TaskInfo) -> int:
        """Get the timeout for task execution in seconds.

        Args:
            task_info: The loaded task information

        Returns:
            Timeout in seconds (default 600)
        """
        # Try common metadata keys for timeout
        metadata = task_info.metadata
        return (
            metadata.get("max_agent_timeout_sec")
            or metadata.get("time_limit")
            or metadata.get("agent", {}).get("timeout_sec")
            or 36000
        )

    @abstractmethod
    def get_supported_agents(self) -> List[str]:
        """Return list of supported agent identifiers for this format.

        Returns:
            List of valid agent slugs (e.g., ["mcp", "terminus_v1"] for Apex)
        """
        pass

    @abstractmethod
    def get_default_agent(self) -> str:
        """Return the default agent for this format.

        Returns:
            Default agent slug
        """
        pass

    def is_valid_agent(self, agent: str) -> bool:
        """Check if an agent is valid for this format.

        Args:
            agent: Agent identifier to validate

        Returns:
            True if the agent is supported, False otherwise
        """
        return agent in self.get_supported_agents()
