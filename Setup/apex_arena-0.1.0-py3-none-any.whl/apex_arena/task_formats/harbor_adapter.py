"""Harbor format adapter for the Harbor framework task format.

This adapter handles tasks in the Harbor framework format:
- task.toml: TOML config with version, metadata, verifier, agent, environment
- instruction.md: Markdown task description
- environment/Dockerfile: Container definition in subdirectory
- solution/solve.sh: Optional reference solution
- tests/test.sh: Test script that produces reward files

Execution is delegated to the Harbor CLI (`harbor run`).

Proxy Integration:
When proxy_url is configured (via APEX_PROXY_URL env or constructor param),
this adapter routes all LLM calls through the Apex proxy for budget tracking.
Model names like 'biggie' are automatically prefixed with 'openai/' for LiteLLM.

Trajectory Upload:
After a run completes, the adapter reads trajectory.json from the job directory,
parses it using harbor_trajectory_parser, and uploads the messages to the apex-ui
API for visualization.
"""

import asyncio
import json
import os
import tomllib
from pathlib import Path
from typing import Dict, List, Optional

import httpx

from .base import GradingResultUnified, TaskFormatAdapter, TaskInfo
from .harbor_trajectory_parser import parse_trajectory_to_messages

# Model info for LiteLLM registration (only token limits, no cost info)
# These are the models supported by the Apex proxy
PROXY_MODEL_INFO = {
    "biggie": {"max_tokens": 200000, "max_input_tokens": 200000},
    "biggie-plus": {"max_tokens": 200000, "max_input_tokens": 200000},
    "smallie": {"max_tokens": 200000, "max_input_tokens": 200000},
    "smallie-plus": {"max_tokens": 200000, "max_input_tokens": 200000},
    "smalli-nebula": {"max_tokens": 200000, "max_input_tokens": 200000},
    "starburst": {"max_tokens": 200000, "max_input_tokens": 1000000},
    "starburst-plus": {"max_tokens": 200000, "max_input_tokens": 1000000},
    "astromax": {"max_tokens": 200000, "max_input_tokens": 200000},
    "zenith": {"max_tokens": 131072, "max_input_tokens": 131072},
    "zenith-quick": {"max_tokens": 131072, "max_input_tokens": 131072},
    "nova": {"max_tokens": 131072, "max_input_tokens": 131072},
    "nova-plus": {"max_tokens": 131072, "max_input_tokens": 131072},
    "nova-ultra": {"max_tokens": 131072, "max_input_tokens": 131072},
}


class HarborFormatAdapter(TaskFormatAdapter):
    """Adapter for the Harbor framework task format.

    This adapter delegates execution to the `harbor` CLI and reads
    reward files produced by the Harbor test scripts.

    Task Structure:
        tasks/{task_id}/
        ├── task.toml          # Required: TOML config
        ├── instruction.md     # Required: Task description
        ├── environment/       # Container definition
        │   └── Dockerfile
        ├── solution/          # Optional reference solution
        │   └── solve.sh
        └── tests/             # Test/grading scripts
            └── test.sh

    Grading:
        Harbor writes reward files to logs/verifier/:
        - reward.txt: Single numeric score
        - reward.json: JSON with score and optional metrics

    Proxy Integration:
        When proxy_url is set (via constructor or APEX_PROXY_URL env),
        LLM calls are routed through the Apex proxy. The api_key
        (from constructor or APEX_API_KEY env) is used for auth.
        Model names are auto-prefixed with 'openai/' for LiteLLM routing.
    """

    def __init__(
        self,
        proxy_url: str = "https://proxy-319533213591.us-west2.run.app",
        api_key: Optional[str] = None,
        apex_api_url: str = "https://apex-ui-v2-319533213591.us-central1.run.app/",
    ):
        """Initialize the Harbor adapter.

        Args:
            proxy_url: URL of the Apex proxy (e.g., 'https://1proxy-url/v1').
                      Falls back to APEX_PROXY_URL environment variable.
            api_key: API key for proxy/API authentication.
                    Falls back to APEX_API_KEY environment variable.
            apex_api_url: Base URL for apex-ui API (e.g., 'https://apex-ui.example.com').
                         Falls back to APEX_UI_API_URL environment variable.
                         Used for uploading trajectory messages.
        """
        self.proxy_url = proxy_url or os.getenv("APEX_PROXY_URL")
        self.api_key = api_key or os.getenv("APEX_API_KEY")
        self.apex_api_url = apex_api_url or os.getenv("APEX_SERVER_URL")

    @property
    def format_name(self) -> str:
        return "harbor"

    def is_valid_task(self, task_dir: Path) -> bool:
        """Check for task.toml and instruction.md."""
        task_toml = task_dir / "task.toml"
        instruction_md = task_dir / "instruction.md"
        return task_toml.exists() and instruction_md.exists()

    def discover_tasks(self, base_dir: Path) -> List[str]:
        """Discover all harbor-format tasks in the directory."""
        valid_tasks = []
        if not base_dir.exists():
            return valid_tasks

        for task_path in base_dir.iterdir():
            if task_path.is_dir() and self.is_valid_task(task_path):
                valid_tasks.append(task_path.name)

        return sorted(valid_tasks)

    def load_task(self, task_id: str, base_dir: Path) -> TaskInfo:
        """Load harbor task metadata and instruction."""
        task_dir = base_dir / task_id
        task_toml_path = task_dir / "task.toml"
        instruction_path = task_dir / "instruction.md"

        if not task_toml_path.exists():
            raise ValueError(
                f"Task {task_id} not found: {task_toml_path} does not exist"
            )

        if not instruction_path.exists():
            raise ValueError(f"Task {task_id} missing instruction.md")

        # Parse TOML config
        with open(task_toml_path, "rb") as f:
            config = tomllib.load(f)

        # Read instruction markdown
        prompt = instruction_path.read_text()

        # Build unified metadata from TOML sections
        metadata = {
            "version": config.get("version", "1.0"),
            "source": config.get("source"),
            **config.get("metadata", {}),
            "verifier": config.get("verifier", {}),
            "agent": config.get("agent", {}),
            "environment": config.get("environment", {}),
        }

        # Harbor Dockerfile is in environment/ subdirectory
        dockerfile_path = task_dir / "environment" / "Dockerfile"

        return TaskInfo(
            task_id=task_id,
            prompt=prompt,
            image_prompts=[],  # Harbor typically doesn't use image prompts
            metadata=metadata,
            format_type="harbor",
            dockerfile_path=dockerfile_path if dockerfile_path.exists() else None,
            task_dir=task_dir,
        )

    async def run_and_grade(
        self,
        task_id: str,
        task_dir: Path,
        model: str,
        agent: str,
        timeout: int = 7200,
        evaluation_id: Optional[str] = None,
        rollout_id: Optional[str] = None,
        **kwargs,
    ) -> GradingResultUnified:
        """Execute via harbor CLI and read reward files.

        Harbor handles the full rollout (Docker, agent loop, grading).
        We just call the CLI and read the resulting reward file.

        When proxy_url is configured, this method:
        1. Prepends 'openai/' to model name for LiteLLM routing
        2. Passes api_base to the agent via --ak flag
        3. Sets OPENAI_API_KEY for LiteLLM authentication

        After completion, if evaluation_id and rollout_id are provided,
        uploads trajectory messages to the apex-ui API.

        Args:
            task_id: The task identifier
            task_dir: Path to the task directory
            model: Model identifier (e.g., 'biggie', 'starburst')
            agent: Agent type for harbor CLI
            timeout: Maximum execution time in seconds
            evaluation_id: Evaluation ID for trajectory upload (optional)
            rollout_id: Rollout ID for trajectory upload, also used as --job-name
            **kwargs: Additional arguments passed to harbor CLI

        Returns:
            GradingResultUnified with the grading result
        """
        # Use rollout_id as job name for traceability, or generate full UUID
        import uuid

        job_name = rollout_id or str(uuid.uuid4())

        # Determine effective model name for LiteLLM
        # When using proxy, prepend 'openai/' for LiteLLM routing
        effective_model = f"openai/{model}"

        # Compute cache directory for job outputs
        # Place jobs in tasks/.cache/<task-id>/jobs to avoid uploading them
        task_id = task_dir.name
        cache_dir = task_dir.parent / ".cache" / task_id
        jobs_dir = cache_dir / "jobs"
        jobs_dir.mkdir(parents=True, exist_ok=True)

        # Build harbor CLI command
        cmd = [
            "harbor",
            "run",
            "-p",
            str(task_dir),
            "-a",
            agent,
            "-m",
            effective_model,
            "--job-name",
            job_name,
            "--jobs-dir",
            str(jobs_dir),
        ]

        # Add proxy configuration via agent kwargs
        # Terminus 2 accepts api_base directly and passes it to LiteLLM
        if self.proxy_url:
            cmd.extend(["--ak", f"api_base={self.proxy_url}"])
            # Register model info for LiteLLM (custom models need this)
            # Use model-specific info if available, otherwise default to 200k
            info = PROXY_MODEL_INFO.get(
                model, {"max_tokens": 200000, "max_input_tokens": 200000}
            )
            cmd.extend(["--ak", f"model_info={json.dumps(info)}"])

        # Add any additional CLI options from kwargs
        if kwargs.get("parallelization"):
            cmd.extend(["-n", str(kwargs["parallelization"])])

        if kwargs.get("env"):
            cmd.extend(["--env", kwargs["env"]])

        try:
            # Execute harbor CLI with real-time output streaming
            # Don't capture stdout/stderr - let them flow to console
            print(f"[harbor] Running: {' '.join(cmd)}")

            # Prepare environment with proxy API key if configured
            env = os.environ.copy()
            if self.proxy_url and self.api_key:
                # LiteLLM uses OPENAI_API_KEY for openai/ prefixed models
                env["OPENAI_API_KEY"] = self.api_key
                env["HOSTED_VLLM_API_KEY"] = self.api_key

            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=None,  # Stream to parent's stdout
                stderr=None,  # Stream to parent's stderr
                cwd=str(task_dir),
                env=env,
            )

            try:
                await asyncio.wait_for(process.wait(), timeout=timeout)
            except asyncio.TimeoutError:
                process.kill()
                await process.wait()
                return GradingResultUnified(
                    score=0.0,
                    subscores={"execution": 0.0},
                    weights={"execution": 1.0},
                    feedback=f"Harbor CLI timed out after {timeout}s",
                )

            if process.returncode != 0:
                return GradingResultUnified(
                    score=0.0,
                    subscores={"execution": 0.0},
                    weights={"execution": 1.0},
                    feedback=f"Harbor CLI failed (exit {process.returncode})",
                )

            # Upload trajectory if API details are provided
            print(
                f"[harbor] DEBUG: evaluation_id={evaluation_id}, rollout_id={rollout_id}"
            )
            print(
                f"[harbor] DEBUG: apex_api_url={self.apex_api_url}, api_key={'set' if self.api_key else 'not set'}"
            )
            if evaluation_id and rollout_id:
                print(f"[harbor] Uploading trajectory for job {job_name}...")
                await self._upload_trajectory(
                    jobs_dir=jobs_dir,
                    job_name=job_name,
                    evaluation_id=evaluation_id,
                    rollout_id=rollout_id,
                )
            else:
                print(
                    "[harbor] Skipping trajectory upload: evaluation_id or rollout_id not provided"
                )

            # Read reward files from the specific job directory
            return self._read_reward_files(jobs_dir, job_name=job_name)

        except Exception as e:
            return GradingResultUnified(
                score=0.0,
                subscores={"execution": 0.0},
                weights={"execution": 1.0},
                feedback=f"Error executing harbor: {str(e)}",
            )

    def _read_reward_files(
        self, jobs_dir: Path, job_name: Optional[str] = None
    ) -> GradingResultUnified:
        """Read reward files from Harbor output.

        Harbor writes results in multiple locations:
        1. <jobs_dir>/<job_name>/<run_id>/verifier/ - Per-run verifier output:
           - reward.json: JSON with key-value pairs for each subscore
           - reward.txt: Simple float score (alternative to JSON)
           - test-stdout.txt: Test stdout for feedback
           - test-stderr.txt: Test stderr for feedback
        2. <jobs_dir>/<job_name>/result.json - Aggregated results (fallback)

        Args:
            jobs_dir: Path to the jobs directory (e.g., tasks/.cache/<task-id>/jobs)
            job_name: Specific job name to read results from (avoids race conditions)

        Returns:
            GradingResultUnified with parsed reward data including subscores and feedback
        """
        # If job_name is provided, look for that specific job directory
        if job_name and jobs_dir.exists():
            job_dir = jobs_dir / job_name

            # Find the verifier directory inside the run subdirectory
            verifier_dir = self._find_verifier_dir(job_dir)

            if verifier_dir and verifier_dir.exists():
                return self._parse_verifier_output(verifier_dir)

            # Fall back to result.json if no verifier dir
            result_json = job_dir / "result.json"
            if result_json.exists():
                return self._parse_harbor_result_json(result_json)

            return GradingResultUnified(
                score=0.0,
                subscores={"reward_file": 0.0},
                weights={"reward_file": 1.0},
                feedback=f"No verifier output or result.json found in {job_dir}",
            )

        # Fall back: check jobs/ directory for the latest result
        if jobs_dir.exists():
            job_dirs = sorted(jobs_dir.iterdir(), reverse=True)
            for jd in job_dirs:
                if jd.is_dir():
                    verifier_dir = self._find_verifier_dir(jd)
                    if verifier_dir and verifier_dir.exists():
                        return self._parse_verifier_output(verifier_dir)
                    result_json = jd / "result.json"
                    if result_json.exists():
                        return self._parse_harbor_result_json(result_json)

        return GradingResultUnified(
            score=0.0,
            subscores={"reward_file": 0.0},
            weights={"reward_file": 1.0},
            feedback=f"No reward file found in {jobs_dir}",
        )

    def _find_verifier_dir(self, job_dir: Path) -> Optional[Path]:
        """Find the verifier directory inside a job directory.

        The verifier dir is located at: jobs/<job_name>/<run_id>/verifier/
        where <run_id> is like 'task-name__randomId'
        """
        if not job_dir.exists():
            return None

        for subdir in job_dir.iterdir():
            if subdir.is_dir():
                verifier_dir = subdir / "verifier"
                if verifier_dir.exists():
                    return verifier_dir
        return None

    def _parse_verifier_output(self, verifier_dir: Path) -> GradingResultUnified:
        """Parse all verifier output files for score, subscores, and feedback.

        Reads:
        - reward.json: Key-value pairs for subscores (preferred)
        - reward.txt: Simple float score (fallback)
        - test-stdout.txt, test-stderr.txt, and other files: Concatenated as feedback
        """
        reward_json_path = verifier_dir / "reward.json"
        reward_txt_path = verifier_dir / "reward.txt"

        subscores: Dict[str, float] = {}
        weights: Dict[str, float] = {}
        score = 0.0

        # Try reward.json first (contains key-value pairs for subscores)
        if reward_json_path.exists():
            try:
                with open(reward_json_path) as f:
                    data = json.load(f)

                if isinstance(data, dict):
                    # Flat key-value pairs: {"test1": 0.5, "test2": 1.0}
                    # Filter to only numeric values for subscores
                    for key, value in data.items():
                        if isinstance(value, (int, float)):
                            subscores[key] = float(value)

                    if subscores:
                        # Equal weights for all subscores
                        weight_per_score = 1.0 / len(subscores)
                        weights = {name: weight_per_score for name in subscores}
                        score = sum(s * weights[n] for n, s in subscores.items())
                    else:
                        # No numeric keys, try standard format
                        score = float(data.get("score", data.get("reward", 0.0)))
                        subscores = {"score": score}
                        weights = {"score": 1.0}

                elif isinstance(data, (int, float)):
                    score = float(data)
                    subscores = {"score": score}
                    weights = {"score": 1.0}

            except (json.JSONDecodeError, ValueError):
                # Fall through to reward.txt
                pass

        # Fall back to reward.txt for simple score
        if not subscores and reward_txt_path.exists():
            try:
                content = reward_txt_path.read_text().strip()
                score = float(content)
                subscores = {"score": score}
                weights = {"score": 1.0}
            except ValueError:
                pass

        # If still no score, return error
        if not subscores:
            return GradingResultUnified(
                score=0.0,
                subscores={"reward_file": 0.0},
                weights={"reward_file": 1.0},
                feedback=f"No valid reward file found in {verifier_dir}",
            )

        # Collect all log files as feedback dict (each file as separate key)
        logs_dict = self._collect_verifier_logs(verifier_dir)

        return GradingResultUnified(
            score=score,
            subscores=subscores,
            weights=weights,
            # Store logs as details with "feedback" key so they appear under metadata.feedback
            details={"feedback": logs_dict} if logs_dict else None,
        )

    def _collect_verifier_logs(self, verifier_dir: Path) -> Dict[str, str]:
        """Collect all log files from verifier directory as feedback.

        Reads all files except reward.txt and reward.json, returns a dict
        with filename as key and content as value for easier viewing in UI.

        Returns:
            Dict mapping filename to file content
        """
        excluded_files = {"reward.txt", "reward.json"}
        logs: Dict[str, str] = {}

        for file_path in sorted(verifier_dir.iterdir()):
            if file_path.is_file() and file_path.name not in excluded_files:
                try:
                    content = file_path.read_text()
                    # Truncate very long files
                    if len(content) > 10000:
                        content = content[:10000] + "\n... [truncated]"
                    logs[file_path.name] = content
                except Exception as e:
                    logs[file_path.name] = f"[Error reading file: {e}]"

        return logs

    def _parse_harbor_result_json(self, result_json: Path) -> GradingResultUnified:
        """Parse Harbor's jobs/<timestamp>/result.json format.

        Harbor result.json has structure:
        {
            "stats": {
                "evals": {
                    "<agent>__<model>__<dataset>": {
                        "metrics": [{"mean": <score>}]
                    }
                }
            }
        }
        """
        try:
            with open(result_json) as f:
                data = json.load(f)

            # Extract score from stats.evals.<key>.metrics[0].mean
            stats = data.get("stats", {})
            evals = stats.get("evals", {})

            if not evals:
                return GradingResultUnified(
                    score=0.0,
                    subscores={"parse_error": 0.0},
                    weights={"parse_error": 1.0},
                    feedback=f"No evals found in {result_json}",
                )

            # Get the first (and usually only) eval key
            eval_key = next(iter(evals.keys()))
            eval_data = evals[eval_key]

            # Extract mean score from metrics
            metrics = eval_data.get("metrics", [])
            if metrics and isinstance(metrics[0], dict):
                score = metrics[0].get("mean", 0.0)
            else:
                score = 0.0

            return GradingResultUnified(
                score=float(score),
                subscores={"mean": float(score)},
                weights={"mean": 1.0},
                feedback=f"Parsed from {result_json.name}",
                details={
                    "n_trials": stats.get("n_trials", 1),
                    "n_errors": stats.get("n_errors", 0),
                    "eval_key": eval_key,
                },
            )

        except (json.JSONDecodeError, KeyError, StopIteration) as e:
            return GradingResultUnified(
                score=0.0,
                subscores={"parse_error": 0.0},
                weights={"parse_error": 1.0},
                feedback=f"Failed to parse Harbor result.json: {str(e)}",
            )

    def _parse_reward_json(self, reward_json: Path) -> GradingResultUnified:
        """Parse reward.json file."""
        try:
            with open(reward_json) as f:
                data = json.load(f)

            # Handle different JSON structures
            if isinstance(data, dict):
                # Standard format: {"score": 0.8, "metrics": {...}, "feedback": "..."}
                score = data.get("score", data.get("reward", 0.0))
                subscores = data.get("metrics", data.get("subscores", {"score": score}))
                weights = data.get("weights", {k: 1.0 for k in subscores})
                feedback = data.get("feedback", "")
                details = {
                    k: v
                    for k, v in data.items()
                    if k
                    not in (
                        "score",
                        "reward",
                        "metrics",
                        "subscores",
                        "weights",
                        "feedback",
                    )
                }
            elif isinstance(data, (int, float)):
                # Simple numeric format
                score = float(data)
                subscores = {"score": score}
                weights = {"score": 1.0}
                feedback = ""
                details = None
            else:
                return GradingResultUnified(
                    score=0.0,
                    subscores={"parse_error": 0.0},
                    weights={"parse_error": 1.0},
                    feedback=f"Unexpected reward.json format: {type(data)}",
                )

            return GradingResultUnified(
                score=float(score),
                subscores=subscores,
                weights=weights,
                feedback=feedback,
                details=details if details else None,
            )

        except json.JSONDecodeError as e:
            return GradingResultUnified(
                score=0.0,
                subscores={"parse_error": 0.0},
                weights={"parse_error": 1.0},
                feedback=f"Failed to parse reward.json: {str(e)}",
            )

    def _parse_reward_txt(self, reward_txt: Path) -> GradingResultUnified:
        """Parse reward.txt file (single numeric value)."""
        try:
            content = reward_txt.read_text().strip()
            score = float(content)
            return GradingResultUnified(
                score=score,
                subscores={"score": score},
                weights={"score": 1.0},
                feedback="Graded via reward.txt",
            )
        except ValueError as e:
            return GradingResultUnified(
                score=0.0,
                subscores={"parse_error": 0.0},
                weights={"parse_error": 1.0},
                feedback=f"Failed to parse reward.txt: {str(e)}",
            )

    async def _upload_trajectory(
        self,
        jobs_dir: Path,
        job_name: str,
        evaluation_id: str,
        rollout_id: str,
    ) -> bool:
        """Read trajectory.json and upload messages to apex-ui API.

        Reads the trajectory file from <jobs_dir>/<job_name>/trajectory.json,
        parses it using harbor_trajectory_parser, and POSTs the messages
        to the apex-ui batch messages endpoint.

        Args:
            jobs_dir: Path to the jobs directory (e.g., tasks/.cache/<task-id>/jobs)
            job_name: Name of the job (subdirectory under jobs_dir)
            evaluation_id: Evaluation ID for the API endpoint
            rollout_id: Rollout ID for the API endpoint

        Returns:
            True if upload succeeded, False otherwise
        """
        if not self.apex_api_url or not self.api_key:
            print(
                "[harbor] Trajectory upload skipped: apex_api_url or api_key not configured"
            )
            return False

        # Find trajectory.json in the job directory
        # Path is: <jobs_dir>/<job_name>/<run_id>/agent/trajectory.json
        # Since we do one run per job, just find the first trajectory.json
        job_dir = jobs_dir / job_name
        trajectory_path = None
        for path in job_dir.rglob("trajectory.json"):
            trajectory_path = path
            break

        if not trajectory_path or not trajectory_path.exists():
            print(f"[harbor] No trajectory.json found in {job_dir}")
            return False

        print(f"[harbor] Found trajectory at {trajectory_path}")

        try:
            # Read and parse trajectory
            with open(trajectory_path) as f:
                trajectory_data = json.load(f)

            # Convert to apex-ui messages format
            messages = parse_trajectory_to_messages(trajectory_data)

            if not messages:
                print("[harbor] No messages found in trajectory")
                return False

            # Build API endpoint URL
            api_url = f"{self.apex_api_url.rstrip('/')}/api/evaluations/{evaluation_id}/rollouts/{rollout_id}/messages"

            # POST messages to apex-ui API
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    api_url,
                    json={"messages": messages},
                    headers={
                        "Authorization": f"Bearer {self.api_key}",
                        "Content-Type": "application/json",
                    },
                    timeout=30.0,
                )

                if response.status_code == 200:
                    result = response.json()
                    print(
                        f"[harbor] Uploaded {result.get('message_count', len(messages))} messages to apex-ui"
                    )
                    return True
                else:
                    print(
                        f"[harbor] Failed to upload trajectory: {response.status_code} - {response.text}"
                    )
                    return False

        except json.JSONDecodeError as e:
            print(f"[harbor] Failed to parse trajectory.json: {e}")
            return False
        except httpx.HTTPError as e:
            print(f"[harbor] HTTP error uploading trajectory: {e}")
            return False
        except Exception as e:
            print(f"[harbor] Error uploading trajectory: {e}")
            return False

    def get_dockerfile_path(self, task_id: str, base_dir: Path) -> Optional[Path]:
        """Return path to Dockerfile in environment/ subdirectory."""
        dockerfile = base_dir / task_id / "environment" / "Dockerfile"
        return dockerfile if dockerfile.exists() else None

    def get_supported_agents(self) -> List[str]:
        """Return list of supported agents for Harbor format.

        Harbor format supports these agent types (from Terminal-Bench leaderboard):
        - claude-code: Claude Code agent (default)
        - terminus-2: Terminus version 2 agent
        - codex-cli: OpenAI Codex CLI agent
        - gemini-cli: Google Gemini CLI agent
        - openhands: OpenHands agent
        - mini-swe-agent: Mini SWE Agent
        - goose: Goose agent
        - aider: Aider agent
        """
        return [
            "claude-code",
            "terminus-2",
            "codex-cli",
            "gemini-cli",
            "openhands",
            "mini-swe-agent",
            "goose",
            "aider",
        ]

    def get_default_agent(self) -> str:
        """Return default agent for Harbor format."""
        return "terminus-2"
