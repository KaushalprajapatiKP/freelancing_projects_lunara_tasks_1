"""Apex format adapter for the original Apex Arena task format.

This adapter handles tasks in the original Apex Arena format:
- task.yaml: YAML config with prompt and metadata
- grader.py: Python module with grade(transcript) -> GradingResult
- Dockerfile: Container definition (flat, in task root)
- solution.sh: Optional reference solution
- setup.sh: Optional setup script
"""

import base64
import importlib.util
import re
import sys
from pathlib import Path
from typing import List, Optional

import yaml

from .base import GradingResultUnified, TaskFormatAdapter, TaskInfo

# Standard prompt template from prompts.py
APEX_TEMPLATE = """If the question asks for a solution, enclose your final solution within answer tags: <answer>(your solution)</answer>. This
will also end the conversation. \
Only code between the very first set of answer tags will be graded, so make sure you're as certain as \
possible about your solution before writing it out with answer tags! If imports are required, \
make sure to include them inside the tags as well.

Otherwise, just output "<DONE>" to end the conversation when you're done with the task that you were assigned. \

Here is the problem I want you to solve:
<problem>
<STATEMENT>
</problem>

Note: your working directory is /workdir.
"""


class ApexFormatAdapter(TaskFormatAdapter):
    """Adapter for the original Apex Arena task format.

    This adapter wraps existing functionality from prompts.py and task_resolver.py
    to provide a unified interface for task handling.

    Task Structure:
        tasks/{task_id}/
        ├── task.yaml      # Required: prompt and metadata
        ├── grader.py      # Required: grade(transcript) function
        ├── Dockerfile     # Optional: custom container
        ├── solution.sh    # Optional: reference solution
        └── setup.sh       # Optional: setup script
    """

    @property
    def format_name(self) -> str:
        return "apex"

    def is_valid_task(self, task_dir: Path) -> bool:
        """Check for task.yaml and grader.py."""
        task_yaml = task_dir / "task.yaml"
        grader_py = task_dir / "grader.py"
        return task_yaml.exists() and grader_py.exists()

    def discover_tasks(self, base_dir: Path) -> List[str]:
        """Discover all apex-format tasks in the directory."""
        valid_tasks = []
        if not base_dir.exists():
            return valid_tasks

        for task_path in base_dir.iterdir():
            if task_path.is_dir() and self.is_valid_task(task_path):
                valid_tasks.append(task_path.name)

        return sorted(valid_tasks)

    def load_task(self, task_id: str, base_dir: Path) -> TaskInfo:
        """Load apex task metadata and prompt."""
        task_dir = base_dir / task_id
        task_yaml_path = task_dir / "task.yaml"

        if not task_yaml_path.exists():
            raise ValueError(f"Task {task_id} not found at {task_yaml_path}")

        with open(task_yaml_path) as f:
            task_data = yaml.safe_load(f)

        # Load image prompts if present
        image_prompts = self._load_image_prompts(task_dir, task_data)

        # Apply standard prompt template
        raw_prompt = task_data.get("prompt", "")
        prompt = self._apply_template(raw_prompt)

        # Get dockerfile path
        dockerfile_path = task_dir / "Dockerfile"

        return TaskInfo(
            task_id=task_id,
            prompt=prompt,
            image_prompts=image_prompts,
            metadata=task_data.get("metadata", {}),
            format_type="apex",
            dockerfile_path=dockerfile_path if dockerfile_path.exists() else None,
            task_dir=task_dir,
        )

    def _load_image_prompts(self, task_dir: Path, task_data: dict) -> List[str]:
        """Load and base64-encode image prompts."""
        image_prompts = []
        image_paths = task_data.get("image_prompt_paths", [])

        for image_path in image_paths:
            full_path = task_dir / image_path
            if full_path.exists():
                with open(full_path, "rb") as img_file:
                    encoded = base64.b64encode(img_file.read()).decode("utf-8")
                    image_prompts.append(encoded)

        return image_prompts

    def _apply_template(self, statement: str) -> str:
        """Apply the standard apex prompt template."""
        return "\n\n" + APEX_TEMPLATE.replace("<STATEMENT>", statement)

    async def run_and_grade(
        self,
        task_id: str,
        task_dir: Path,
        model: str,
        agent: str,
        transcript: str = "",
        **kwargs,
    ) -> GradingResultUnified:
        """Grade using the Python grader module.

        For apex format, the actual rollout is handled by EvalRunner using
        the MCP server. This method is called with the transcript after
        the rollout completes.

        Args:
            task_id: The task identifier
            task_dir: Path to the task directory
            model: Model identifier (unused for apex grading)
            agent: Agent type (unused for apex grading)
            transcript: The conversation transcript containing the solution

        Returns:
            GradingResultUnified with the grading result
        """
        grader_path = task_dir / "grader.py"

        if not grader_path.exists():
            return GradingResultUnified(
                score=0.0,
                subscores={"grader_found": 0.0},
                weights={"grader_found": 1.0},
                feedback=f"grader.py not found at {grader_path}",
            )

        try:
            # Dynamically import the grader module
            grader_module = self._import_grader(grader_path)

            # Extract solution from answer tags
            solution = self._extract_solution(transcript)

            # Call the grader
            result = grader_module.grade(solution)

            # Convert to unified format
            return self._convert_grading_result(result)

        except Exception as e:
            return GradingResultUnified(
                score=0.0,
                subscores={"execution": 0.0},
                weights={"execution": 1.0},
                feedback=f"Error during grading: {str(e)}",
            )

    def _import_grader(self, grader_path: Path):
        """Dynamically import the grader module."""
        spec = importlib.util.spec_from_file_location("grader", grader_path)
        grader_module = importlib.util.module_from_spec(spec)

        # Store in sys.modules to handle relative imports
        sys.modules["grader"] = grader_module
        spec.loader.exec_module(grader_module)

        return grader_module

    def _extract_solution(self, transcript: str) -> str:
        """Extract solution from <answer> tags in transcript."""
        # Find all answer tags and take the last one
        matches = re.findall(r"<answer>(.*?)</answer>", transcript, re.DOTALL)
        if matches:
            return matches[-1].strip()
        return transcript

    def _convert_grading_result(self, result) -> GradingResultUnified:
        """Convert apex GradingResult to unified format."""
        # Handle different result formats
        if hasattr(result, "subscores") and hasattr(result, "weights"):
            subscores = dict(result.subscores) if result.subscores else {}
            weights = dict(result.weights) if result.weights else {}
            score = self._calculate_weighted_score(subscores, weights)
            feedback = getattr(result, "feedback", None)
            details = getattr(result, "details", None)
        elif hasattr(result, "score"):
            score = float(result.score)
            subscores = {"score": score}
            weights = {"score": 1.0}
            feedback = getattr(result, "feedback", None)
            details = None
        else:
            # Assume result is a numeric score
            score = float(result)
            subscores = {"score": score}
            weights = {"score": 1.0}
            feedback = None
            details = None

        return GradingResultUnified(
            score=score,
            subscores=subscores,
            weights=weights,
            feedback=feedback,
            details=details,
        )

    def _calculate_weighted_score(
        self, subscores: dict, weights: dict
    ) -> float:
        """Calculate weighted score from subscores."""
        if not subscores or not weights:
            return 0.0

        total = 0.0
        for key, subscore in subscores.items():
            weight = weights.get(key, 0.0)
            total += subscore * weight

        return total

    def get_dockerfile_path(self, task_id: str, base_dir: Path) -> Optional[Path]:
        """Return path to Dockerfile in task root."""
        dockerfile = base_dir / task_id / "Dockerfile"
        return dockerfile if dockerfile.exists() else None

    def get_supported_agents(self) -> List[str]:
        """Return list of supported agents for Apex format.

        Apex format supports these agent types:
        - mcp: Model Context Protocol agent (default)
        - terminus_v1: Terminus version 1 agent
        - terminus_v2: Terminus version 2 agent
        """
        return ["mcp", "terminus_v1", "terminus_v2"]

    def get_default_agent(self) -> str:
        """Return default agent for Apex format."""
        return "mcp"
